﻿// ContentPlaceHolder ID
var CPH = "ctl00_CPH_";
var Panel1 = CPH + "PersonalInfo_";
var Panel2 = CPH + "ChoiceProgram_";
var Panel3 = CPH + "EduQualification_";
var Panel4 = CPH + "Achievement_";
var Panel5 = CPH + "OtherInfo_";
var Panel6 = CPH + "Declaration_";
var Panel7 = CPH + "Medicine_";
var RFeild1, RFeild2, RFeild3, SingAddress, ForAddress, PrStatus_HF, NavPl_HF, FormName_HF;
//////******************************************************************************************
//////------------- Start CheckOnClientClick----------------

function ConvertMonthInt(month) {
    var mon = month.toUpperCase();
    var monthValue;
    switch (mon) {
        case 'JAN':
            monthValue = 0;
            break;
        case 'FEB':
            monthValue = 1;
            break;
        case 'MAR':
            monthValue = 2;
            break;
        case 'APR':
            monthValue = 3;
            break;
        case 'MAY':
            monthValue = 4;
            break;
        case 'JUN':
            monthValue = 5;
            break;
        case 'JUL':
            monthValue = 6;
            break;
        case 'AUG':
            monthValue = 7;
            break;
        case 'SEP':
            monthValue = 8;
            break;
        case 'OCT':
            monthValue = 9;
            break;
        case 'NOV':
            monthValue = 10;
            break;
        case 'DEC':
            monthValue = 11;
            break;
    }
    return monthValue;
}
function SubmitClientClick() {
    PrStatus_HF = document.getElementById("ctl00_PrStatus_HF").value;
    NavPl_HF = document.getElementById("ctl00_NavPl_HF").value;
    var subflag = 0;
    var SubPerInfo = PersonalInfo();

    if (SubPerInfo == "Error") {
        subflag = 1;
        return false;
    }
    else if (SubPerInfo == "Ref_Field") {
        subflag = 1;
        alert("* Please fill in all required fields. (1)");
        return false;
    }
    else if (SubPerInfo == "Validated") {
        document.getElementById("ctl00_PERSONAL_INFO_HF").value = "Validated";
    }
    var SubChoPro = ChoiceProgram();
    if (SubChoPro == "Ref_Field") {
        subflag = 1;
        alert("* Please fill in all required fields. (2)");
        return false;
    }
    var SubEduQualif = EduQulification();
    if (SubEduQualif == "Error") {
        subflag = 1;
        return false;
    }
    else if (SubEduQualif == "Ref_Field") {
        subflag = 1;
        alert("* Please fill in all required fields. (3)");
        return false;
    }
    else if (SubEduQualif == "SubError") {
        subflag = 1;
        alert("* Please fill in all required fields and fileds alerted with the error message to proceed. (4)");
        return false;
    }
    FormName_HF = document.getElementById("ctl00_FormName_HF").value;
    if (FormName_HF != "SM2") {
        var SubAchInfo = AchievementInfo();
        if (SubAchInfo == "Ref_Field") {
            subflag = 1;
            alert("* Please fill in all required fields. (5)");
            return false;
        }
    }
    var SubAchInfo = MedicineInfo();
    if (SubAchInfo == "Ref_Field") {
        subflag = 1;
        alert("* Please fill in all required fields. (6)");
        return false;
    }

    var SubOthInfo = OtherInfo();

    if (SubOthInfo == "Error") {
        subflag = 1;
        return false;
    }
    else if (SubOthInfo == "Ref_Field") {
        subflag = 1;
        alert("* Please fill in all required fields. (7)");
        return false;
    }

    var SubDeclaration = Declaration();
    if (SubDeclaration == "Error") {
        subflag = 1;
        return false;
    }
    else if (SubDeclaration == "Ref_Field") {
        subflag = 1;
        alert("* Please fill in all required fields. (8)");
        return false;
    }
    if (subflag == 0) {
        return true;
    }

}
//////******************************************************************************************
//////------------- Start CheckOnClientClick----------------
function CheckOnClientClick(Btnval) {

    PrStatus_HF = document.getElementById("ctl00_PrStatus_HF").value;
    NavPl_HF = document.getElementById("ctl00_NavPl_HF").value;
    if (NavPl_HF != Btnval) {
        switch (NavPl_HF) {
            case "PERSONAL_INFO":

                var RtnPerInfo = PersonalInfo();
                if (RtnPerInfo == "Error") {
                    return false;
                }
                else if (RtnPerInfo == "Ref_Field") {
                    document.getElementById("ctl00_PERSONAL_INFO_HF").value = "Ref_Field";
                }
                else if (RtnPerInfo == "Validated") {
                    document.getElementById("ctl00_PERSONAL_INFO_HF").value = "Validated";
                }

                break;

            case "CHOICE_PROGRAM":

                var RtnChoPro = ChoiceProgram();
                if (RtnChoPro == "Ref_Field") {
                    document.getElementById("ctl00_CHOICE_PROGRAM_HF").value = "Ref_Field";
                }
                else if (RtnChoPro == "Validated") {
                    document.getElementById("ctl00_CHOICE_PROGRAM_HF").value = "Validated";
                }
                break;

            case "EDU_QUALIFICATION":
                var RtnEduQualif = EduQulification();
                if (RtnEduQualif == "Error") {
                    return false;
                }
                else if (RtnEduQualif == "Ref_Field") {
                    document.getElementById("ctl00_EDU_QUALIFICATION_HF").value = "Ref_Field";
                }
                else if (RtnEduQualif == "Validated") {
                    document.getElementById("ctl00_EDU_QUALIFICATION_HF").value = "Validated";
                }
                else if (RtnEduQualif == "SubError") {
                    document.getElementById("ctl00_EDU_QUALIFICATION_HF").value = "SubError";
                }
                break;
            case "BIOMEDICAL_INFO":

                var RtnAchInfo = MedicineInfo();
                if (RtnAchInfo == "Ref_Field") {
                    document.getElementById("ctl00_BIOMEDICAL_INFO_HF").value = "Ref_Field";
                    subflag = 1;
                    alert("* Please fill in all required fields. (9)");
                    return false;
                }
                else if (RtnAchInfo == "Validated") {
                    document.getElementById("ctl00_BIOMEDICAL_INFO_HF").value = "Validated";
                }
                else {
                    return true;
                }

                break;
            case "ACHIEVEMENT_INFO":

                var RtnAchInfo = AchievementInfo();
                if (RtnAchInfo == "Ref_Field" || RtnAchInfo == "Ref_Field1") {
                    document.getElementById("ctl00_ACHIEVEMENT_INFO_HF").value = "Ref_Field";
                    subflag = 1;
                    alert("* Please fill in all required fields. (10)");
                    return false;
                }
                else if (RtnAchInfo == "Validated") {
                    document.getElementById("ctl00_ACHIEVEMENT_INFO_HF").value = "Validated";
                }
                else {
                    return true;
                }

                break;

            case "OTHER_INFO":
                var RtnOthInfo = OtherInfo();

                if (RtnOthInfo == "Error") {
                    return false;
                }
                else if (RtnOthInfo == "Ref_Field") {
                    document.getElementById("ctl00_OTHER_INFO_HF").value = "Ref_Field";
                }
                else if (RtnOthInfo == "Validated") {
                    document.getElementById("ctl00_OTHER_INFO_HF").value = "Validated";
                }

                break;
            case "DECLARATION_INFO":
                var RtnDeclaration = Declaration();
                if (RtnDeclaration == "Error") {
                    return false;
                }
                else if (RtnDeclaration == "Ref_Field") {
                    document.getElementById("ctl00_DECLARATION_INFO_HF").value = "Ref_Field";
                }
                else if (RtnDeclaration == "Validated") {
                    document.getElementById("ctl00_DECLARATION_INFO_HF").value = "Validated";
                }
                break;
        }
    }
    else {
        return false;
    }

    return true;
}


/////----------- End ToeflSatIelts----------------
//////******************************************************************************************
//////------------- Start ToeflSatIelts----------------

function ToeflSatIelts() {
    //--------------Start Check Toefl------
    var ToeflYr = document.getElementById(Panel5 + "ToeflYrTaken_TXT").value;
    var ToeflScore = document.getElementById(Panel5 + "ToeflScore_TXT").value;
    var ToeflTestMode = document.getElementById(Panel5 + "ToeflTestMode_DDL").value;
    document.getElementById(Panel5 + "Toefl_EMsg").innerHTML = "";
    var ToeflMsg = "";
    var ErrorFlag = 0;
    if (ToeflYr != "" && ToeflScore == "" && ToeflTestMode == "") {
        ToeflMsg = "* Please provide the TOEFL score & indicate your TOEFL Test Mode.";
    }
    else if (ToeflYr == "" && ToeflScore != "" && ToeflTestMode == "") {
        ToeflMsg = "* Please provide the TOEFL Year taken & indicate your TOEFL Test Mode.";
    }
    else if (ToeflYr == "" && ToeflScore == "" && ToeflTestMode != "") {
        ToeflMsg = "* Please provide the TOEFL Year taken & TOEFL score.";
    }
    else if (ToeflYr != "" && ToeflScore != "" && ToeflTestMode == "") {
        ToeflMsg = "* Please indicate your TOEFL Test Mode.";
    }
    else if (ToeflYr == "" && ToeflScore != "" && ToeflTestMode != "") {
        ToeflMsg = "* Please provide the  TOEFL Year taken.";
    }
    else if (ToeflYr != "" && ToeflScore == "" && ToeflTestMode != "") {
        ToeflMsg = "* Please provide the TOEFL score.";
    }
    if (ToeflMsg != "") {
        document.getElementById(Panel5 + "Toefl_EMsg").innerHTML = ToeflMsg;
        ErrorFlag = 1;
    }
    // End Check Toefl

    //--------------Start Check Sat------
    var SatMonthYr = document.getElementById(Panel5 + "SatMonthYr_TXT").value;
    var SatVerbal = document.getElementById(Panel5 + "SatVerbal_TXT").value;
    var SatMath = document.getElementById(Panel5 + "SatMath_TXT").value;
    var SatWriting = document.getElementById(Panel5 + "SatWriting_TXT").value;
    var SatEssay = document.getElementById(Panel5 + "SatEssay_TXT").value;
    document.getElementById(Panel5 + "SAT_EMsg").innerHTML = "";
    var SATEMsg = "";

    if (SatMonthYr != "" && SatVerbal == "" && SatMath == "" && SatWriting == "" && SatEssay == "") {
        SATEMsg = "* Please provide the SAT1 Critical Reading or Maths or Writing or Essay score.";
    }
    /*else if(SatMonthYr != "" &&  SatVerbal != "" && SatMath == "" && SatWriting == "" && SatEssay == "")
    {
    SATEMsg = "* Please provide the SAT1 Critical Reading, Maths, Writing and Eassay score."; 
    }
    else if(SatMonthYr != "" &&  SatVerbal == "" && SatMath != "" && SatWriting != "" && SatEssay != "")
    {
    SATEMsg = "* Please provide the SAT1 Critical Reading."; 
    }
    else if(SatMonthYr == "" &&  SatVerbal != "" && SatMath != "" && SatWriting != "" && SatEssay != "")
    {
    SATEMsg = "* Please provide the SAT1 Month-Year."; 
    }
    else if(SatMonthYr == "" &&  SatVerbal == "" && SatMath != "" && SatWriting != "" && SatEssay != "")
    {
    SATEMsg = "* Please provide the SAT1 Month-Year & Critical Reading."; 
    }
    else if(SatMonthYr == "" &&  SatVerbal != "" && SatMath == "" && SatWriting != "" && SatEssay != "")
    {
    SATEMsg = "* Please provide the SAT1 Month-Year & Maths score.";
    }
    else if(SatEssay !="" && SatMonthYr == "" &&  SatVerbal == "" && SatMath == "" && SatWriting == "" )
    {
    SATEMsg = "* Please provide the SAT1 Month-Year, Critical Reading , Maths score & Writing";
    }*/
    if (SATEMsg != "") {
        document.getElementById(Panel5 + "SAT_EMsg").innerHTML = SATEMsg;
        ErrorFlag = 1;
    }
    // End Check Sat

    //--------------Start Check Ielts------
    var IeltsDate = document.getElementById(Panel5 + "IeltsDate_TXT").value;
    var IeltsBand = document.getElementById(Panel5 + "IeltsBand_TXT").value;
    var IeltsWrite = document.getElementById(Panel5 + "IeltsWriting_TXT").value;
    document.getElementById(Panel5 + "Ielts_EMsg").innerHTML = "";
    var IeltsEMsg = "";

    if (IeltsDate != "" && IeltsBand == "" && IeltsWrite == "") {
        IeltsEMsg = "* Please provide the IELTS Band & Writing.";
    }
    else if (IeltsDate == "" && IeltsBand != "" && IeltsWrite == "") {
        IeltsEMsg = "* Please provide the IELTS Date & Writing.";
    }
    else if (IeltsDate == "" && IeltsBand == "" && IeltsWrite != "") {
        IeltsEMsg = "* Please provide the IELTS Date & Band.";
    }
    else if (IeltsDate != "" && IeltsBand != "" && IeltsWrite == "") {
        IeltsEMsg = "* Please indicate your IELTS Writing.";
    }
    else if (IeltsDate == "" && IeltsBand != "" && IeltsWrite != "") {
        IeltsEMsg = "* Please provide the  IELTS Date.";
    }
    else if (IeltsDate != "" && IeltsBand == "" && IeltsWrite != "") {
        IeltsEMsg = "* Please provide the IELTS Band.";
    }
    if (IeltsEMsg != "") {
        document.getElementById(Panel5 + "Ielts_EMsg").innerHTML = IeltsEMsg;
        ErrorFlag = 1;
    }
    // End check Ielts 
    //--------------Start Check PTE------
    var PteDate = document.getElementById(Panel5 + "PteDate_TXT").value;
    var PteOverall = document.getElementById(Panel5 + "PteScore_TXT").value;
    var PteWrite = document.getElementById(Panel5 + "PteWriting_TXT").value;
    document.getElementById(Panel5 + "Pte_EMsg").innerHTML = "";
    var PteEMsg = "";

    if (PteDate != "" && PteOverall == "" && PteWrite == "") {
        PteEMsg = "* Please provide the PTE Overall Score & Writing.";
    }
    else if (PteDate == "" && PteOverall != "" && PteWrite == "") {
        PteEMsg = "* Please provide the PTE Date & Writing.";
    }
    else if (PteDate == "" && PteOverall == "" && PteWrite != "") {
        PteEMsg = "* Please provide the PTE Date & Overall Score.";
    }
    else if (PteDate != "" && PteOverall != "" && PteWrite == "") {
        PteEMsg = "* Please indicate your PTE Writing.";
    }
    else if (PteDate == "" && PteOverall != "" && PteWrite != "") {
        PteEMsg = "* Please provide the  PTE Date.";
    }
    else if (PteDate != "" && PteOverall == "" && PteWrite != "") {
        PteEMsg = "* Please provide the PTE Overall Score.";
    }
    if (PteEMsg != "") {
        document.getElementById(Panel5 + "Pte_EMsg").innerHTML = PteEMsg;
        ErrorFlag = 1;
    }
    // End check Pte 
    if (ErrorFlag == 1) {
        return false;
    }
    else {
        return true;
    }
}
/////----------- End ToeflSatIelts----------------

//////******************************************************************************************
//////------------- Start PersonalInfo----------------
function PersonalInfo() {
    RFeild1 = 0;
    
    SingAddress = document.getElementById(Panel1 + "SingPerAdd_Sing_PerPostcode_TXT").value;
    ForAddress = document.getElementById(Panel1 + "PermenentADD_TXT1").value;
    if (SingAddress != "" || ForAddress != "") {
        var RequiredFields_Ary = new Array();
        RequiredFields_Ary[0] = Panel1 + "Title_DDL";
        RequiredFields_Ary[1] = Panel1 + "Name_TXT";
        RequiredFields_Ary[2] = Panel1 + "NricNo_TXT";
        RequiredFields_Ary[3] = Panel1 + "SingaporePR_DDL";
        RequiredFields_Ary[4] = Panel1 + "CitizenShip_DLL";
        RequiredFields_Ary[5] = Panel1 + "Gender_DDL";
        //RequiredFields_Ary[6]= Panel1+"Country_OB_DDL";//Remove country validation on 17-09-2013
        RequiredFields_Ary[6] = Panel1 + "DOBirth_TXT";
        RequiredFields_Ary[7] = Panel1 + "Email_1_TXT";
        RequiredFields_Ary[8] = Panel1 + "Permenent_PhoneLocalNo_TXT";
        if (ForAddress != "") {
            RequiredFields_Ary[9] = Panel1 + "PermenentCountry_DDL";
        }
        for (i = 0; i <= RequiredFields_Ary.length - 1; i++) {
            var Fields_AryValue = document.getElementById(RequiredFields_Ary[i]).value;
            if (Fields_AryValue == "" || Fields_AryValue == "0") {
                RFeild1 = 1;
            }
        }
        var SingaporePR_DDLValue = document.getElementById(Panel1 + "SingaporePR_DDL").value;
        if (RFeild1 != 1) {
            
            var CitizenShip_DDLValue = document.getElementById(Panel1 + "CitizenShip_DLL").value;
            if (SingaporePR_DDLValue != "SG") {
                if (CitizenShip_DDLValue == "SG") {
                    alert("* Citizenship is incorrect for non-Singaporean/PR!");
                    return "Error";
                }
            }
        }
        if (SingaporePR_DDLValue == "SG") {
            var Race_DDLValue = document.getElementById(Panel1 + "Race_DDL").value;
            if (Race_DDLValue == "") {
                RFeild1 = 1;
            }
        }
    }
    else if (SingAddress == "" || ForAddress == "") {
        RFeild1 = 1;
    }

    if (document.getElementById(Panel1 + "NRIC_ErrorMsg").innerHTML != "") {

        alert("* NRIC is invalid. Please check.");
        return "Error";
    }
    if (document.getElementById(Panel1 + "DOBirth_RFV").style.display != 'none') {
        alert("* Date of Birth format is incorrect!");
        return "Error";
    }
    else {
        var dob12 = document.getElementById(Panel1 + "DOBirth_TXT").value;
        if (dob12 != "") {
            var splittxtval = dob12.split("-");
            var today = new Date();
            var CurntYear = today.getFullYear();
            var enteryear = splittxtval[2];
            if ((CurntYear - 12) < enteryear) {
                alert("* Your age must be at least 12 years to apply please check the Date of Birth field.");
                document.getElementById(Panel1 + "DOBirth_TXT").focus();
                return "Error";
            }
        }
    }
    if (document.getElementById(Panel1 + "SingPerAdd_SingPerAdd_EMsg").innerHTML != "") {
        alert("* Singapore postal code invalid. Please check.");
        return "Error";
    }
    if (document.getElementById(Panel1 + "SingPostAdd_SingPostAdd_EMsg").innerHTML != "") {
        alert("* Singapore postal code invalid. Please check.");
        return "Error";
    }
    if (document.getElementById(Panel1 + "Email_1_RFV").style.display != 'none') {
        alert("* Email 1 format is incorrect!");
        return "Error";
    }
    if (document.getElementById(Panel1 + "Email_2_RFV").style.display != 'none') {
        alert("* Email 2 format is incorrect!");
        return "Error";
    }
    if (PrStatus_HF == "SG") {
        var EnlistmentDate = document.getElementById(Panel1 + "EnlistmentDate_RFV");
        if (EnlistmentDate != null) {
            if (EnlistmentDate.style.display != 'none') {
                alert("* Enlistment date format is incorrect!");
                return "Error";
            }
        }
        var Operational = document.getElementById(Panel1 + "OperationalReadyDate_RFV");
        if (Operational != null) {
            if (Operational.style.display != 'none') {
                alert("* Operational ready date format is incorrect!");
                return "Error";
            }
        }
        var Gender_DDLValue = document.getElementById(Panel1 + "Gender_DDL").value;
        if (Gender_DDLValue == "M") {
            var NationalService = document.getElementById(Panel1 + "NationalService_DDL").value;
            if (NationalService == "1" || NationalService == "10" || NationalService == "5") {
                var EnlistmentDate = document.getElementById(Panel1 + "EnlistmentDate_TXT").value;
                var OperationalDate = document.getElementById(Panel1 + "OperationalReadyDate_TXT").value;
                if (EnlistmentDate == "") {
                    alert("* Enlistment date is required!");
                    return "Error";
                }
                else if (OperationalDate == "") {
                    alert("* Operational date is required!");
                    return "Error";
                }

//to validate the dates added on 3 oct 2018
                var fromdate =  OperationalDate;
                var todate = EnlistmentDate;

                if (fromdate != null || todate != null || !isNaN(fromdate) || isNaN(todate)) {
                    dt1 = parseInt(fromdate.substring(0, 2), 10);
                    mon1 = parseInt(ConvertMonthInt(fromdate.substring(3, 6), 10));
                    yr1 = parseInt(fromdate.substring(7, 11), 10);

                    dt2 = parseInt(todate.substring(0, 2), 10);
                    mon2 = parseInt(ConvertMonthInt(todate.substring(3, 6), 10));
                    yr2 = parseInt(todate.substring(7, 11), 10);

                    stDate = new Date(yr1, mon1, dt1);
                    endDate = new Date(yr2, mon2, dt2);

                    if (stDate <= endDate) {
                        alert("The OperationalDate should not be less than or equal to EnlistmentDate!");
                        return "Error";
                    }
                }
           }
//            else
//                RFeild1 = 0;
        }
//        else
//            RFeild1 = 0;
    }

    if (RFeild1 == 1) {
        return "Ref_Field";
    }
    else if (RFeild1 != 1) {

        return "Validated";
    }

}
/////----------- End PersonalInfo----------------
//////******************************************************************************************
//////------------- Start ChoiceProgram----------------
function ChoiceProgram() {
    if (document.getElementById(Panel2 + "ProgramChoice_DDL1").value == "") {
        RFeild2 = 1;
    }
    else {
        RField2 = 0;
    }
    if (PrStatus_HF == "N") {
        var FinancialStatus_1 = document.getElementById(Panel2 + "FinancialStatus_RBtn1");
        var FinancialStatus_2 = document.getElementById(Panel2 + "FinancialStatus_RBtn2");
        if (FinancialStatus_1 != null) {
            if (FinancialStatus_1.checked == false && FinancialStatus_2.checked == false) {
                RFeild2 = 1;
            }
        }
    }
    if (RFeild2 == 1) {
        return "Ref_Field";
    }
    else {
        return "Validated";
    }
}
/////----------- End ChoiceProgram----------------
//////******************************************************************************************
//////------------- Start AchievementInfo----------------
function AchievementInfo() {
    var RVFlag = 0;
    FormName_HF = document.getElementById("ctl00_FormName_HF").value;
    var PersonalEassy = 'ctl00_CPH_Achievement_PersonalEssay_TXTA';
    var ActivityLevel = 'ctl00_CPH_Achievement_ActivityLevel_DDL1';
    var ActivityName = 'ctl00_CPH_Achievement_ActivityName_TXT1';
    var PositionHeld = 'ctl00_CPH_Achievement_PositionHeld_TXT1';
    var ActivityFromDate = 'ctl00_CPH_Achievement_ActivityFromDate_TXT1';
    var ActivityToDate = 'ctl00_CPH_Achievement_ActivityToDate_TXT1';
    var ActivityDesc = 'ctl00_CPH_Achievement_ListOFAward_TXT1';
    var errorMsg = "Please provide atleast one activity details";
    var errorMsg1 = "Complete Section A (atleast activity 1) & B of the form";
    if (document.getElementById(Panel4 + "NonAcademicAchievements_PL") != null) {
        var AcademicAchievements = document.getElementById(Panel4 + "NonAcademicAchievements_DDL");
        var Cardedathlete = document.getElementById(Panel4 + "Cardedathlete_DDL");
        var CardedYear = document.getElementById(Panel4 + "txtCardedYear");
        if (AcademicAchievements != null) {
            if (AcademicAchievements.value == "" ) {
                return "Ref_Field";
            }
            else {
                if (AcademicAchievements.value == "Y") {
                    if (Cardedathlete.value == "") {
                        return "Ref_Field";
                    }
                    if (Cardedathlete.value != "" && Cardedathlete.value != "NAA_CA1") {
                        if (CardedYear.value == "") {
                            return "Ref_Field";
                        }
                    }
                    
                    if (document.getElementById(ActivityLevel).value == '' &&
					document.getElementById(ActivityName).value == '' &&
					document.getElementById(PositionHeld).value == '' &&
					 document.getElementById(ActivityFromDate).value == '' &&
					 document.getElementById(ActivityToDate).value == '' &&
					 document.getElementById(ActivityDesc).value == '' &&
					 document.getElementById(PersonalEassy).value == '') {
                        alert(errorMsg1);
                        document.getElementById(ActivityLevel).selectedIndex = 0;
                        document.getElementById(ActivityLevel).focus();
                        return "Ref_Field1";
                    }
                    else if (document.getElementById(ActivityLevel).value == '' &&
					 document.getElementById(ActivityName).value == '' &&
					 document.getElementById(PositionHeld).value == '' &&
					 document.getElementById(ActivityFromDate).value == '' &&
					 document.getElementById(ActivityToDate).value == '' &&
					 document.getElementById(ActivityDesc).value == '') {
                        alert(errorMsg);
                        document.getElementById(ActivityLevel).selectedIndex = 0;
                        document.getElementById(ActivityLevel).focus();
                        return "Ref_Field1";
                    }
                    else if (document.getElementById(ActivityLevel).value != '') {
                        if (document.getElementById(ActivityName).value == '') {
                            alert('Please indicate name of activity/event/competition');
                            document.getElementById(ActivityName).focus();
                            return "Ref_Field1";
                        }
                        else if (document.getElementById(PositionHeld).value == '') {
                            alert('Please indicate position held');
                            document.getElementById(PositionHeld).focus();
                            return "Ref_Field1";
                        }
                        else if (document.getElementById(ActivityFromDate).value == '') {
                            alert('Please provide the start date in ‘From’ column in MMM-YYYY format');
                            document.getElementById(ActivityFromDate).focus();
                            return "Ref_Field1";
                        }
                        else if (document.getElementById(ActivityFromDate).value != '' && !isValidDate(document.getElementById(ActivityFromDate).value)) {
                            document.getElementById(ActivityFromDate).value = '';
                            alert('Please provide the start date in ‘From’ column in MMM-YYYY format');
                            document.getElementById(ActivityFromDate).focus();
                            return "Ref_Field1";
                        }
                        else if (document.getElementById(ActivityToDate).value == '') {
                            alert('Please provide the end date in ‘To’ column in MMM-YYYY format');
                            document.getElementById(ActivityToDate).focus();
                            return "Ref_Field1";
                        }
                        else if (document.getElementById(ActivityToDate).value != '' && !isValidDate(document.getElementById(ActivityToDate).value)) {
                            document.getElementById(ActivityToDate).value = '';
                            alert('Please provide the end date in ‘To’ column in MMM-YYYY format');
                            document.getElementById(ActivityToDate).focus();
                            return "Ref_Field1";
                        }
                        else if (document.getElementById(ActivityDesc).value == '') {
                            alert('Please list awards/certificates received or elaborate your involvements');
                            document.getElementById(ActivityDesc).focus();
                            return "Ref_Field1";
                        }
                        else if (document.getElementById(PersonalEassy).value == '') {
                            alert("Please Complete Section B");
                            return "Ref_Field1";
                        }
                        else {
                            return "Validated";
                        }
                    }
                    else {
                        return "Validated";
                    }

                }
                else {
                    return "Validated";
                }
            }
        }
        else {
            return "Validated";
        }
    }
    else {
        return "Validated";
    }
}
/////----------- End AchievementInfo----------------
//////******************************************************************************************
//////------------- Start MedicineInfo----------------
function MedicineInfo() {
    var RVFlag = 0;
    var FormName_HF = document.getElementById("ctl00_BIOMEDICAL_INFO_HF").value;
    var PersonalEassy = 'ctl00_CPH_Medicine_PersonalEssay_TXTA';
    var BMATNmbr = 'ctl00_CPH_Medicine_BMATCandidate_TXTA';
    var errorMsg = "Please provide the BMAT Candidate Number and Personal Statement.";
    var errorMsg1 = "Please provide the BMAT Candidate Number.";
    var errorMsg2 = "Please provide the Personal Statement.";
    if (document.getElementById(Panel7 + "BioMedical_PL") != null) {
        var BioMedical = document.getElementById(Panel7 + "Biomedical_DDL");
        if (BioMedical != null) {
            if (BioMedical.value == "") {
                return "Ref_Field";
            }
            else {
                if (BioMedical.value == "Y") {
                    if (document.getElementById(BMATNmbr).value == '' &&
					document.getElementById(PersonalEassy).value == '') {
                        document.getElementById(BMATNmbr).focus();
                        return "Ref_Field";
                    }
                    else if (document.getElementById(BMATNmbr).value == '') {
                        document.getElementById(BMATNmbr).focus();
                        return "Ref_Field";
                    }
                    else if (document.getElementById(PersonalEassy).value == '') {
                        document.getElementById(PersonalEassy).focus();
                        return "Ref_Field";
                    }
                    else
                        return "Validated";
                }
                else {
                    return "Validated";
                }
            }
        }
    }
}
/////----------- End MedicineInfo----------------
//////******************************************************************************************
//////------------- Start OtherInfo----------------
function OtherInfo() {
    var RVFlag = 0;
    if (ToeflSatIelts() == false) {
        alert("* Please fill in all fields alerted with the error message to proceed. (11)")
        setTimeout('window.scrollTo(0,0)', 200);
        return "Error";
    }
    if (document.getElementById(Panel5 + "SatMonthYr_RE").style.display != 'none') {
        alert("* SAT Month-Year format is incorrect!");
        return "Error";
    }
    if (document.getElementById(Panel5 + "IELTSDate_RE").style.display != 'none') {
        alert("* IELTS date format is incorrect!");
        return "Error";
    }
    if (document.getElementById(Panel5 + "ToeflDate_RE").style.display != 'none') {
        alert("* TOEFL date format is incorrect!");
        return "Error";
    }
    if (document.getElementById(Panel5 + "PteSDate_RE").style.display != 'none') {
        alert("* PTE date format is incorrect!");
        return "Error";
    }


    FormName_HF = document.getElementById("ctl00_FormName_HF").value;


    if (FormName_HF == "SMU" || FormName_HF == "VIETNAM") {
        //if (document.getElementById(Panel5 + "NtuEExamVenue_DDL").value == "") {
        //    RVFlag = 1;
        //}
        var EExam = document.getElementById(Panel5 + "PreNtuEExam_DLL").value;
        if (EExam == "") {
            RVFlag = 1;
        }

        else if (EExam == "Y") {
            if (document.getElementById(Panel5 + "PreNtuExamYr_TXT").value == "" || document.getElementById(Panel5 + "PreNtuExamStatus_DDL").value == "") {
                RVFlag = 1;
            }
        }
    }

    if (FormName_HF != "SM2") {
        if (document.getElementById(Panel5 + "ApplHistory_DDL").value == "") {
            RVFlag = 1;
        }
        else if (document.getElementById(Panel5 + "ApplHistory_DDL").value == "Y") {
            if (document.getElementById(Panel5 + "ReasonNotAcceptNTUOff_TXTA").value == "") {
                RVFlag = 1;
            }
        }
        var PrevStudyLocalUni = document.getElementById(Panel5 + "PrevStudyLocalUni_DLL").value
        if (PrevStudyLocalUni == "") {
            RVFlag = 1;
        }
        else if (PrevStudyLocalUni == "Y" && (document.getElementById(Panel5 + "PreStudyLocalUniName_DDL").value == "" || document.getElementById(Panel5 + "TuitionFee_TXT").value == "")) {
            RVFlag = 1;
        }

        var CurAcadStatus = document.getElementById(Panel5 + "CurAcadStatus_DDL").value
        if (CurAcadStatus == "") {
            RVFlag = 1;
        }
        else if (CurAcadStatus == "Y" && document.getElementById(Panel5 + "CurAcadStatus_TXTA").value == "") {
            RVFlag = 1;
        }

    }
    var DisSplNeeds = document.getElementById(Panel5 + "DisSplNeeds_DDL").value
    if (DisSplNeeds == "") {
        RVFlag = 1;
    }
    else if (DisSplNeeds == "Y" && document.getElementById(Panel5 + "DisSplNeeds_TXTA").value == "") {
        RVFlag = 1;
    }
    //    var CriminalOffence = document.getElementById(Panel5 + "CriminalOffence_DLL").value
    //    if (CriminalOffence == "") {
    //        RVFlag = 1;
    //    }
    //    else if (CriminalOffence == "Y" && document.getElementById(Panel5 + "CriminalOffence_TXTA").value == "") {
    //        RVFlag = 1;
    //    }

    if (document.getElementById(Panel5 + "NtuOthers_CB") != null) {
        if (document.getElementById(Panel5 + "NtuOthers_CB").checked == true && document.getElementById(Panel5 + "NTUOtherSpecify_TXT").value == "") {
            alert("* Please specify how did you learn about the NTU");
            return "Error";
        }
    }


    if (RVFlag == 1) {
        return "Ref_Field";
    }
    else {
        return "Validated";
    }
}
/////----------- End OtherInfo----------------
//////******************************************************************************************
//////------------- Start Declaration----------------
function Declaration() {
    if (document.getElementById(Panel6 + "Password_TXT").value == "") {
        return "Ref_Field";
    }
    else if (document.getElementById(Panel6 + "Password_TXTEMsg").innerHTML != "") {
    alert("* Password must be between 8 to 20 characters \n with at least one Capital letter (A-Z), \n at least one lower case letter (a-z), \n at least one number (0 – 9) and \n at least one of this special Characters !@#$%&()*");
        return "Error";
    }
    else {
        return "Validated";
    }
}
/////----------- End Declaration----------------
//////******************************************************************************************
//////------------- Start EduQulification----------------
function EduQulification() {
    var RtnEdu = "";
    FormName_HF = document.getElementById("ctl00_FormName_HF").value;
    if (FormName_HF == "PRC") {
        RtnEdu = PRCEduField();
    }
    else if (FormName_HF == "SM2") {
        RtnEdu = SM2EduField();
    }
    else if (FormName_HF == "NUSHS") {
        RtnEdu = NUSHSEduField();
    }
    else if (FormName_HF == "IB") {
        RtnEdu = IBEduField();
    }
    else if (FormName_HF == "SMU") {
        RtnEdu = SMUEduField();
    }
    else if (FormName_HF == "USHS") {
        RtnEdu = USHSEduField();
    }
    else if (FormName_HF == "INDIA") {
        RtnEdu = INDIAEduField();
    }
    else if (FormName_HF == "OTHERS") {
        RtnEdu = OTHERSEduField();
    }
    else if (FormName_HF == "USTPM") {
        RtnEdu = USTPMEduField();
    }
    else if (FormName_HF == "VIETNAM") {
        RtnEdu = VIETNAMEduField();
    }
    else if (FormName_HF == "UKLEVELA") {
        RtnEdu = UKLEVELAEduField();
    }
    if (RtnEdu == "Error") {
        return "Error";
    }
    else if (RtnEdu == "Ref_Field") {
        return "Ref_Field";
    }
    else if (RtnEdu == "Validated") {
        return "Validated";
    }
    else if (RtnEdu == "SubError") {
        return "SubError";
    }

}
/////----------- End EduQulification----------------
//////******************************************************************************************
//////------------- Start UKLEVELAEduField----------------
function UKLEVELAEduField() {
    var OTHAcadStatus = document.getElementById(Panel3 + "AcademicStatus_DDL").value;
    if (OTHAcadStatus == "") {
        return "Ref_Field";
    }
    else if (OTHAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_REV").style.display != 'none') {
            alert("* Results available format is not correct!");
            return "Error";
        }
    }

    var OTHProgramme = document.getElementById(Panel3 + "ALevelCountry_DDL").value;
    var OTHHSchName = document.getElementById(Panel3 + "HSchName_DDL").value;
    var ExamBoard = document.getElementById(Panel3 + "Examboard_DDL").value;
    

    if (ExamBoard == "") {
        return "Ref_Field";
    }
    if (ExamBoard == "OTH") {
        var OTHExamBoard = document.getElementById(Panel3 + "OthXStdBoard_TXT").value;
        if (OTHExamBoard == "" ) {
            return "Ref_Field";
        }
    }
    
    if (OTHProgramme == "" || OTHHSchName == "") {
        return "Ref_Field";
    }
    if (OTHHSchName == "OTH") {
        var OTHOthSchName = document.getElementById(Panel3 + "OthSchName_TXT").value;
        var OTHOthSchAdd = document.getElementById(Panel3 + "OthSchAdd_TXT").value;
        var OTHOthSchCountry = document.getElementById(Panel3 + "OthSchCountry_TXT").value;
        if (OTHOthSchName == "" || OTHOthSchAdd == "" || OTHOthSchCountry == "") {
            return "Ref_Field";
        }
    }
    if (document.getElementById(Panel3 + "PhySubHSchool_DDL").value == "") {
        return "Ref_Field";
    }
    if (document.getElementById(Panel3 + "HSchStudyStream_DDL").value == "") {
        return "Ref_Field";
    }
    if (OTHAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_TXT").value == "") {
            return "Ref_Field";
        }
        if (document.getElementById(Panel3 + "ALevelMarks_PL").style.display != 'none') {

            if (CheckFirstNSub("HSPreSubTaken_DDL", 25, "HSPreNLSubTaken_TXT", 15, "HSPre_EMsg", 3) == "SubError") {
                RFeild3 = 1;
            }
            else {
                var PreSubAll = CheckSubMarksObtMaxLevel("HSPreSubTaken_DDL", "HSPreGradeObt_TXT", "HSPreBestGrade_TXT", "HSPreLevel_DDL", "HSPre_EMsg", 25)
                if (PreSubAll == "SubError") {
                    RFeild3 = 1;
                }
                else {
                    var NlPreSubAll = CheckSubMarksObtMaxLevel("HSPreNLSubTaken_TXT", "HSPreNLGradeObt_TXT", "HSPreNLBestGrade_TXT", "HSPreNLLevel_DDL", "HSPre_EMsg", 15)
                    if (NlPreSubAll == "SubError") {
                        RFeild3 = 1;
                    }
                }
            }
        }
        else if (document.getElementById(Panel3 + "A2LevelMarks_PL").style.display != 'none') {
            if (CheckFirstNSub("NHSSubTaken_DDL", 25, "NHSNLSubTaken_TXT", 15, "NHS_EMsg", 3) == "SubError") {
                RFeild3 = 1;
            }
            else {
                var HSSubAll = CheckSubMarksObtMaxLevel("NHSSubTaken_DDL", "NHSGradeObt_TXT", "NHSBestGrade_TXT", "NHSLevel_DDL", "NHS_EMsg", 25)
                if (HSSubAll == "SubError") {
                    RFeild3 = 1;
                }
                else {
                    var NlHSSubAll = CheckSubMarksObtMaxLevel("NHSNLSubTaken_TXT", "NHSNLGradeObt_TXT", "NHSNLBestGrade_TXT", "NHSNLLevel_DDL", "NHS_EMsg", 15)
                    if (NlHSSubAll == "SubError") {
                        RFeild3 = 1;
                    }
                }
            }
        }
    }
    if (OTHAcadStatus == "3") {
        if (CheckFirstNSub("NHSSubTaken_DDL", 25, "NHSNLSubTaken_TXT", 15, "NHS_EMsg", 3) == "SubError") {
            RFeild3 = 1;
        }
        else {
            var HSSubAll = CheckSubMarksObtMaxLevel("NHSSubTaken_DDL", "NHSGradeObt_TXT", "NHSBestGrade_TXT", "NHSLevel_DDL", "NHS_EMsg", 25)
            if (HSSubAll == "SubError") {
                RFeild3 = 1;
            }
            else {
                var NlHSSubAll = CheckSubMarksObtMaxLevel("NHSNLSubTaken_TXT", "NHSNLGradeObt_TXT", "NHSNLBestGrade_TXT", "NHSNLLevel_DDL", "NHS_EMsg", 15)
                if (NlHSSubAll == "SubError") {
                    RFeild3 = 1;
                }
            }
        }
    }
    else if (OTHAcadStatus == "2" || OTHAcadStatus == "3") {
        if (OTHAcadStatus == "2") {
            var OTHCurUniName = document.getElementById(Panel3 + "CurUniName_TXT").value;
            var OTHCurProName = document.getElementById(Panel3 + "CurUniProvince_TXT").value;
            var OTHCurProg = document.getElementById(Panel3 + "CurProg_TXT").value;
            var OTHCurYrStudy = document.getElementById(Panel3 + "CurYrStudy_TXT").value;
            if (OTHCurUniName == "" || OTHCurProg == "" || OTHCurYrStudy == "" || OTHCurProName == "") {
                return "Ref_Field";
            }
        }
        else if (OTHAcadStatus == "3") {
            var OTHCompHSCur = document.getElementById(Panel3 + "CompHSCur_TXT").value;
            var OTHHSHighQualif = document.getElementById(Panel3 + "HSHighQualif_TXT").value;
            if (OTHCompHSCur == "" || OTHHSHighQualif == "") {
                return "Ref_Field";
            }
        }
        //        if(document.getElementById(Panel3 + "NHSExYear_TXT").value == "")
        //        {
        //             return "Ref_Field";
        //        }

        if (CheckFirstNSub("NHSSubTaken_DDL", 25, "NHSNLSubTaken_TXT", 15, "NHS_EMsg", 3) == "SubError") {
            RFeild3 = 1;
        }
        else {
            var HSSubAll = CheckSubMarksObtMaxLevel("NHSSubTaken_DDL", "NHSGradeObt_TXT", "NHSBestGrade_TXT", "NHSLevel_DDL", "NHS_EMsg", 25)
            if (HSSubAll == "SubError") {
                RFeild3 = 1;
            }
            else {
                var NlHSSubAll = CheckSubMarksObtMaxLevel("NHSNLSubTaken_TXT", "NHSNLGradeObt_TXT", "NHSNLBestGrade_TXT", "NHSNLLevel_DDL", "NHS_EMsg", 15)
                if (NlHSSubAll == "SubError") {
                    RFeild3 = 1;
                }
            }
        }
    }

    if (RFeild3 == 1) {
        return "SubError";
    }
    else {
        return "Validated";
    }
}


/////----------- End UKLEVELAEduField----------------
//////******************************************************************************************
//////------------- Start USTPMEduField----------------
function USTPMEduField() {
    var USTPMAcadStatus = document.getElementById(Panel3 + "AcademicStatus_DDL").value;
    if (USTPMAcadStatus == "") {
        return "Ref_Field";
    }
    else if (USTPMAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_REV").style.display != 'none') {
            alert("* Results available format is not correct!");
            return "Error";
        }
    }
    var USTPMHSchQualif = document.getElementById(Panel3 + "HighSchQualif_DDL").value;
    var USTPMProgramme = document.getElementById(Panel3 + "Programme_DDL").value;
    var USTPMHSchName = document.getElementById(Panel3 + "HSchName_DDL").value;
    if (USTPMHSchQualif == "" || USTPMProgramme == "" || USTPMHSchName == "") {
        return "Ref_Field";
    }

    if (USTPMHSchName == "OTH") {
        var USTPMOthSchName = document.getElementById(Panel3 + "OthSchName_TXT").value;
        var USTPMOthSchAdd = document.getElementById(Panel3 + "OthSchAdd_TXT").value;
        var USTPMOthSchCountry = document.getElementById(Panel3 + "OthSchCountry_TXT").value;
        if (USTPMOthSchName == "" || USTPMOthSchAdd == "" || USTPMOthSchCountry == "") {
            return "Ref_Field";
        }
    }
    if (document.getElementById(Panel3 + "PhySubHSchool_DDL").value == "") {
        return "Ref_Field";
    }

    if (USTPMAcadStatus == "1") {
        if (document.getElementById(Panel3 + "Result_PL").style.display !== 'none') {
            if (document.getElementById(Panel3 + "ResultsAvail_TXT").value == "") {
                return "Ref_Field";
            }
            if (USTPMCurUniName == "" || USTPMCurProg == "" || USTPMCurYrStudy == "" || USTPMProvince == "") {
                return "Ref_Field";
            }
            if (CheckFirstNSub("SubTaken_DDL", 12, "NLSubTaken_TXT", 10, "Sub_EMsg", 4) == "SubError") {
                RFeild3 = 1;
            }
            else {
                if (CheckUSTPMEdu("SubTaken_DDL", "MarksObt_TXT", "MaxMarks_TXT", "Level_DDL", "Sub_EMsg", 4, USTPMHSchQualif) == "SubError") {
                    RFeild3 = 1;
                }
                else {
                    if (CheckUSTPMEdu("NLSubTaken_TXT", "NLMarksObt_TXT", "NLMaxMarks_TXT", "NLLevel_DDL", "Sub_EMsg", 4, USTPMHSchQualif) == "SubError") {
                        RFeild3 = 1;
                    }
                }
            }
        }
    }
    else if (USTPMAcadStatus == "2" || USTPMAcadStatus == "3") {
        if (USTPMAcadStatus == "2") {
            var USTPMCurUniName = document.getElementById(Panel3 + "CurUniName_TXT").value;
            var USTPMProvince = document.getElementById(Panel3 + "CurUniProvince_TXT").value;
            var USTPMCurProg = document.getElementById(Panel3 + "CurProg_TXT").value;
            var USTPMCurYrStudy = document.getElementById(Panel3 + "CurYrStudy_TXT").value;
            if (USTPMCurUniName == "" || USTPMCurProg == "" || USTPMCurYrStudy == "" || USTPMProvince == "") {
                return "Ref_Field";
            }
            if (CheckFirstNSub("SubTaken_DDL", 12, "NLSubTaken_TXT", 10, "Sub_EMsg", 4) == "SubError") {
                RFeild3 = 1;
            }
            else {
                if (CheckUSTPMEdu("SubTaken_DDL", "MarksObt_TXT", "MaxMarks_TXT", "Level_DDL", "Sub_EMsg", 4, USTPMHSchQualif) == "SubError") {
                    RFeild3 = 1;
                }
                else {
                    if (CheckUSTPMEdu("NLSubTaken_TXT", "NLMarksObt_TXT", "NLMaxMarks_TXT", "NLLevel_DDL", "Sub_EMsg", 4, USTPMHSchQualif) == "SubError") {
                        RFeild3 = 1;
                    }
                }
            }
        }
        else if (USTPMAcadStatus == "3") {
            var USTPMCompHSCur = document.getElementById(Panel3 + "CompHSCur_TXT").value;
            var USTPMHSHighQualif = document.getElementById(Panel3 + "HSHighQualif_TXT").value;
            if (USTPMCompHSCur == "" || USTPMHSHighQualif == "") {
                return "Ref_Field";
            }
        }
        if (document.getElementById(Panel3 + "ExYear_TXT").value == "") {
            return "Ref_Field";
        }
        if (CheckFirstNSub("SubTaken_DDL", 12, "NLSubTaken_TXT", 10, "Sub_EMsg", 4) == "SubError") {
            RFeild3 = 1;
        }
        else {
            if (CheckUSTPMEdu("SubTaken_DDL", "MarksObt_TXT", "MaxMarks_TXT", "Level_DDL", "Sub_EMsg", 4, USTPMHSchQualif) == "SubError") {
                RFeild3 = 1;
            }
            else {
                if (CheckUSTPMEdu("NLSubTaken_TXT", "NLMarksObt_TXT", "NLMaxMarks_TXT", "NLLevel_DDL", "Sub_EMsg", 4, USTPMHSchQualif) == "SubError") {
                    RFeild3 = 1;
                }
            }
        }
    }
    document.getElementById(Panel3 + "E1119_EMsg").value = "";
    if (document.getElementById(Panel3 + "E1119NT_CHK").checked == false) {
        if (document.getElementById(Panel3 + "EngLevelYr_TXT").value == "" || document.getElementById(Panel3 + "EngLevelGd_TXT").value == "") {
            document.getElementById(Panel3 + "E1119_EMsg").value = "* Please enter both the Year and Grade of E1119.";
            RFeild3 = 1;
        }
    }
    if (RFeild3 == 1) {
        return "SubError";
    }
    else {
        return "Validated";
    }
}
/////----------- End USTPMEduField----------------
//////******************************************************************************************
//////------------- Start VIETNEMEduField----------------
function VIETNAMEduField() {
    var VIEAcadStatus = document.getElementById(Panel3 + "AcademicStatus_DDL").value;
    if (VIEAcadStatus == "") {
        return "Ref_Field";
    }
    else if (VIEAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_REV").style.display != 'none') {
            alert("* Results available format is incorrect!");
            return "Error";
        }
    }
    var VIEHSchName = document.getElementById(Panel3 + "HSchName_DDL").value;
    var VIEProgramme = document.getElementById(Panel3 + "Programme_DDL").value;
    if (VIEHSchName == "" || VIEProgramme == "") {
        return "Ref_Field";
    }
    if (VIEHSchName == "OTH") {
        if (document.getElementById(Panel3 + "OthSchName_TXT").value == "" || document.getElementById(Panel3 + "OthSchAdd_TXT").value == "") {
            return "Ref_Field"
        }
    }
    if (VIEAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_TXT").value == "") {
            return "Ref_Field";
        }
        if (document.getElementById(Panel3 + "G10ExYear_TXT").value == "" || document.getElementById(Panel3 + "G11ExYear_TXT").value == "") {
            return "Ref_Field";
        }
        if (CheckFirstSixSub("G10SubTaken_DDL", "G10_EMsg") == "SubError") {
            RFeild3 = 1;
        }
        else {
            if (CheckSubMarks("G10SubTaken_DDL", "G10MarksObt_TXT", "G10_EMsg", 6) == "SubError") {
                RFeild3 = 1;
            }
        }
        if (CheckFirstSixSub("G11SubTaken_DDL", "G11_EMsg") == "SubError") {
            RFeild3 = 1;
        }
        else {
            if (CheckSubMarks("G11SubTaken_DDL", "G11MarksObt_TXT", "G11_EMsg", 6) == "SubError") {
                RFeild3 = 1;
            }
        }
    }
    else if (VIEAcadStatus == "2" || VIEAcadStatus == "3") {
        if (VIEAcadStatus == "2") {
            var VIEUniName = document.getElementById(Panel3 + "UniName_DDL").value;
            var VIECurProg = document.getElementById(Panel3 + "CurProg_TXT").value;
            var VIECurYrStudy = document.getElementById(Panel3 + "CurYrStudy_TXT").value;
            if (VIEUniName == "" || VIECurProg == "" || VIECurYrStudy == "") {
                return "Ref_Field";
            }
            if (VIEUniName == "OTH") {
                if (document.getElementById(Panel3 + "OthUniName_TXT").value == "" || document.getElementById(Panel3 + "CurUniProvince_TXT").value == "") {
                    return "Ref_Field";
                }
            }
        }
        else if (VIEAcadStatus == "3") {
            var VIECompHSCur = document.getElementById(Panel3 + "CompHSCur_TXT").value;
            var VIEHSHighQualif = document.getElementById(Panel3 + "HSHighQualif_TXT").value;
            if (VIECompHSCur == "" || VIEHSHighQualif == "") {
                return "Ref_Field";
            }
        }

        if (document.getElementById(Panel3 + "HSExYear_TXT").value == "") {
            return "Ref_Field";
        }
        if (CheckFirstSixSub("HSSubTaken_DDL", "HS_EMsg") == "SubError") {
            RFeild3 = 1;
        }
        else {
            if (CheckSubMarks("HSSubTaken_DDL", "HSMarksObt_TXT", "HS_EMsg", 6) == "SubError") {
                RFeild3 = 1;
            }
        }
    }

    if (RFeild3 == 1) {
        return "SubError";
    }
    else {
        return "Validated";
    }
}

/////----------- End VIETNEMEduField----------------
//////******************************************************************************************
//////------------- Start OTHERSEduField----------------
function OTHERSEduField() {
    var OTHAcadStatus = document.getElementById(Panel3 + "AcademicStatus_DDL").value;
    if (OTHAcadStatus == "") {
        return "Ref_Field";
    }
    else if (OTHAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_REV").style.display != 'none') {
            alert("* Results available format is not correct!");
            return "Error";
        }
    }
    var OTHHighSchQualif = document.getElementById(Panel3 + "HighSchQualif_DDL").value;
    var OTHProgramme = document.getElementById(Panel3 + "Programme_DDL").value;
    var OTHHSchName = document.getElementById(Panel3 + "HSchName_DDL").value;

    if (OTHHighSchQualif == "") {
        return "Ref_Field";
    }
    else if (OTHHighSchQualif == "99") {
        if (document.getElementById(Panel3 + "OthEntrQualif_TXT").value == "") {
            return "Ref_Field";
        }
    }
    if (OTHProgramme == "" || OTHHSchName == "") {
        return "Ref_Field";
    }
    if (OTHHSchName == "OTH") {
        var OTHOthSchName = document.getElementById(Panel3 + "OthSchName_TXT").value;
        var OTHOthSchAdd = document.getElementById(Panel3 + "OthSchAdd_TXT").value;
        var OTHOthSchCountry = document.getElementById(Panel3 + "OthSchCountry_TXT").value;
        if (OTHOthSchName == "" || OTHOthSchAdd == "" || OTHOthSchCountry == "") {
            return "Ref_Field";
        }
    }
    if (document.getElementById(Panel3 + "PhySubHSchool_DDL").value == "") {
        return "Ref_Field";
    }
    if (OTHAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_TXT").value == "") {
            return "Ref_Field";
        }
        if (document.getElementById(Panel3 + "HSPreSub_PL").style.display != 'none') //ADD
        {
            if (document.getElementById(Panel3 + "HSPreExYear_TXT").value == "") {
                return "Ref_Field";
            }

            if (CheckFirstNSub("HSPreSubTaken_DDL", 12, "HSPreNLSubTaken_TXT", 10, "HSPre_EMsg", 3) == "SubError") {
                RFeild3 = 1;
            }
            else {
                if (CheckOthersEdu("HSPreSubTaken_DDL", "HSPreMarksObt_TXT", "HSPreMaxMarks_TXT", "HSPre_EMsg", 12, OTHHighSchQualif) == "SubError") {
                    RFeild3 = 1;
                }
                else {
                    if (CheckOthersEdu("HSPreNLSubTaken_TXT", "HSPreNLMarksObt_TXT", "HSPreNLMaxMarks_TXT", "HSPre_EMsg", 10, OTHHighSchQualif) == "SubError") {
                        RFeild3 = 1;
                    }
                }
            }
        }
        if (document.getElementById(Panel3 + "NHSSubMarks_PL").style.display != 'none') {
            if (document.getElementById(Panel3 + "NHSExYear_TXT").value == "") {
                return "Ref_Field";
            }
            if (CheckFirstNSub("NHSSubTaken_DDL", 12, "NHSNLSubTaken_TXT", 10, "NHS_EMsg", 3) == "SubError") {
                RFeild3 = 1;
            }
        }
    }
    else if (OTHAcadStatus == "2" || OTHAcadStatus == "3") {
        if (OTHAcadStatus == "2") {
            var OTHCurUniName = document.getElementById(Panel3 + "CurUniName_TXT").value;
            var OTHCurProg = document.getElementById(Panel3 + "CurProg_TXT").value;
            var OTHCurYrStudy = document.getElementById(Panel3 + "CurYrStudy_TXT").value;
            if (OTHCurUniName == "" || OTHCurProg == "" || OTHCurYrStudy == "") {
                return "Ref_Field";
            }
        }
        else if (OTHAcadStatus == "3") {
            var OTHCompHSCur = document.getElementById(Panel3 + "CompHSCur_TXT").value;
            var OTHHSHighQualif = document.getElementById(Panel3 + "HSHighQualif_TXT").value;
            if (OTHCompHSCur == "" || OTHHSHighQualif == "") {
                return "Ref_Field";
            }
        }
        if (document.getElementById(Panel3 + "NHSExYear_TXT").value == "") {
            return "Ref_Field";
        }

        if (CheckFirstNSub("NHSSubTaken_DDL", 12, "NHSNLSubTaken_TXT", 10, "NHS_EMsg", 3) == "SubError") {
            RFeild3 = 1;
        }
        else {
            if (CheckOthersEdu("NHSSubTaken_DDL", "NHSMarksObt_TXT", "NHSMaxMarks_TXT", "NHS_EMsg", 12, OTHHighSchQualif) == "SubError") {
                RFeild3 = 1;
            }
            else {
                if (CheckOthersEdu("NHSNLSubTaken_TXT", "NHSNLMarksObt_TXT", "NHSNLMaxMarks_TXT", "NHS_EMsg", 10, OTHHighSchQualif) == "SubError") {
                    RFeild3 = 1;
                }
            }
        }
    }
    if (RFeild3 == 1) {
        return "SubError";
    }
    else {
        return "Validated";
    }
}

/////----------- End OTHERSEduField----------------
//////******************************************************************************************
//////------------- Start INDIAEduField----------------
function INDIAEduField() {
    var INDAcadStatus = document.getElementById(Panel3 + "AcademicStatus_DDL").value;
    if (INDAcadStatus == "") {
        return "Ref_Field";
    }
    else if (INDAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_REV").style.display != 'none') {
            alert("* Results available format is not correct!");
            return "Error";
        }
    }
    //var INDScholar = document.getElementById(Panel3 + "Scholar_DDL").value;
    //var INDIITJEEExam = document.getElementById(Panel3 + "IITJEEExam_DDL").value;
    var INDXExamYear = document.getElementById(Panel3 + "XExamYear_TXT").value;
    var INDXStdBoard = document.getElementById(Panel3 + "XStdBoard_DDL").value;
    var INDXSchName = document.getElementById(Panel3 + "XSchName_TXT").value;
    var INDXSchState = document.getElementById(Panel3 + "XSchState_TXT").value;

    //if (INDScholar == "" || INDXExamYear == "" || INDXStdBoard == "") {
    if (INDXExamYear == "" || INDXStdBoard == "") {
        return "Ref_Field";
    }

    if (INDXStdBoard == "INE34") {
        if (document.getElementById(Panel3 + "OthXStdBoard_TXT").value == "") {
            return "Ref_Field";
        }
    }
    if (INDXSchName == "" || INDXSchState == "") {
        return "Ref_Field";
    }
    var INDXIIExYear = document.getElementById(Panel3 + "XIIExYear_TXT").value;
    var INDXIIStdBoard = document.getElementById(Panel3 + "XIIStdBoard_DDL").value;
    var INDXIIProgramme = document.getElementById(Panel3 + "XIIProgramme_DDL").value;
    var PhysicsValue = document.getElementById(Panel3 + "XIIProgramSelection_DDL").value;

    var INDXIISchName = document.getElementById(Panel3 + "XIISchName_DDL").value;

    if (INDXIIExYear == "" || INDXIIStdBoard == "") {
        return "Ref_Field";
    }
    if (INDXIIStdBoard == "INE34") {
        if (document.getElementById(Panel3 + "XIIOthStdBoard_TXT").value == "") {
            return "Ref_Field";
        }
    }
    if (INDXIIProgramme == "" || INDXIISchName == "" || PhysicsValue == "") {
        return "Ref_Field";
    }
    if (INDXIISchName == "OTH") {
        var INDOthXIISchName = document.getElementById(Panel3 + "OthXIISchName_TXT").value;
        var INDOthXIISchAdd = document.getElementById(Panel3 + "OthXIISchAdd_TXT").value;
        var INDOthXIIState = document.getElementById(Panel3 + "OthXIIState_TXT").value;
        if (INDOthXIISchName == "" || INDOthXIISchAdd == "" || INDOthXIIState == "") {
            return "Ref_Field";
        }
    }
    if (INDAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_TXT").value == "") {
            return "Ref_Field";
        }
    }
    else if (INDAcadStatus == "2") {
        var INDCurUniName = document.getElementById(Panel3 + "CurUniName_TXT").value;
        var INDCurProg = document.getElementById(Panel3 + "CurProg_TXT").value;
        var INDCurYrStudy = document.getElementById(Panel3 + "CurYrStudy_TXT").value;
        if (INDCurUniName == "" || INDCurProg == "" || INDCurYrStudy == "") {
            return "Ref_Field";
        }
    }
    else if (INDAcadStatus == "3") {
        var INDCompHSCur = document.getElementById(Panel3 + "CompHSCur_TXT").value;
        var INDHSHighQualif = document.getElementById(Panel3 + "HSHighQualif_TXT").value;
        if (INDCompHSCur == "" || INDHSHighQualif == "") {
            return "Ref_Field";
        }
    }

    if (CheckFiveSub("XSubTaken_DDL", "XNLSubTaken_TXT", "X_EMsg", 6, 8) == "SubError") {
        RFeild3 = 1;
    }
    else {
        if (CheckSubMarksObtMax("XSubTaken_DDL", "XMarksObt_TXT", "XMaxMarks_TXT", "X_EMsg", 6) == "SubError") {
            RFeild3 = 1;
        }
        else {
            if (CheckSubMarksObtMax("XNLSubTaken_TXT", "XNLMarksObt_TXT", "XNLMaxMarks_TXT", "X_EMsg", 8) == "SubError") {
                RFeild3 = 1;
            }
        }
    }
    if (INDAcadStatus == "2" || INDAcadStatus == "3") {
        if (CheckFiveSub("XIISubTaken_DDL", "XIINLSubTaken_TXT", "XII_EMsg", 6, 8) == "SubError") {
            RFeild3 = 1;
        }
        else {
            if (CheckSubMarksObtMax("XIISubTaken_DDL", "XIIMarksObt_TXT", "XIIMaxMarks_TXT", "XII_EMsg", 6) == "SubError") {
                RFeild3 = 1;
            }
            else {
                if (CheckSubMarksObtMax("XIINLSubTaken_TXT", "XIINLMarksObt_TXT", "XIINLMaxMarks_TXT", "XII_EMsg", 8) == "SubError") {
                    RFeild3 = 1;
                }
            }
        }
    }
    if (RFeild3 == 1) {
        return "SubError";
    }
    else {
        return "Validated";
    }
}
/////----------- End INDIAEduField----------------
//////******************************************************************************************
//////------------- Start USHSEduField----------------
function USHSEduField() {
    var USHSAcadStatus = document.getElementById(Panel3 + "AcademicStatus_DDL").value;
    if (USHSAcadStatus == "") {
        return "Ref_Field";
    }
    else if (USHSAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_REV").style.display != 'none') {
            alert("* Results available format is not correct!");
            return "Error";
        }
    }
    var USHSProgramme = document.getElementById(Panel3 + "Programme_DDL").value;
    var USHSHSchName = document.getElementById(Panel3 + "HSchName_DDL").value;
    var USHSCAPMarksobt = document.getElementById(Panel3 + "CAP_Marksobt_TXT").value;
    var USHSCAPMarksmax = document.getElementById(Panel3 + "CAP_Marksmax_TXT").value;
    if (USHSProgramme == "" || USHSHSchName == "" || USHSCAPMarksobt == "" || USHSCAPMarksmax == "") {
        return "Ref_Field";
    }
    if (USHSHSchName == "OTH") {
        var USHSOthSchName = document.getElementById(Panel3 + "OthSchName_TXT").value;
        var USHSOthSchAdd = document.getElementById(Panel3 + "OthSchAdd_TXT").value;
        var USHSOthSchCountry = document.getElementById(Panel3 + "OthSchCountry_TXT").value;
        if (USHSOthSchName == "" || USHSOthSchAdd == "" || USHSOthSchCountry == "") {
            return "Ref_Field";
        }
    }
    if (USHSAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_TXT").value == "") {
            return "Ref_Field";
        }
    }
    else if (USHSAcadStatus == "2") {
        var USHSCurUniName = document.getElementById(Panel3 + "CurUniName_TXT").value;
        var USHSCurUniProvince = document.getElementById(Panel3 + "CurUniProvince_TXT").value;
        var USHSCurProg = document.getElementById(Panel3 + "CurProg_TXT").value;
        var USHSCurYrStudy = document.getElementById(Panel3 + "CurYrStudy_TXT").value;
        if (USHSCurUniName == "" || USHSCurUniProvince == "" || USHSCurProg == "" || USHSCurYrStudy == "") {
            return "Ref_Field";
        }
    }
    else if (USHSAcadStatus == "3") {
        var USHSCompHSCur = document.getElementById(Panel3 + "CompHSCur_TXT").value;
        var USHSHSHighQualif = document.getElementById(Panel3 + "HSHighQualif_TXT").value;
        if (USHSCompHSCur == "" || USHSHSHighQualif == "") {
            return "Ref_Field";
        }
    }
    var USHSPhySubHSch = document.getElementById(Panel3 + "PhySubHSchool_DDL").value;
    if (USHSPhySubHSch == "") {
        return "Ref_Field";
    }
    var TestTaken = document.getElementById(Panel3 + "AERTest_DDL").value; //New Addition
    if (TestTaken == "") {
        return "Ref_Field";
    }
    if (USHS_LeastSubjectCheck("G11S1_EMsg") == "SubError") {
        RFeild3 = 1;
    }
    if (RFeild3 == 1) {
        return "SubError";
    }
    else {
        return "Validated";
    }
}
function USHS_LeastSubjectCheck(prmErr) {

    var USHSGradeCompare = new Array();
    var USHSNLGradeCompare = new Array();
    var found = 0;
    var GradeCount11 = 0;
    var GradeCount12 = 0;
    var ushsgrade = '';
    var ushsnlgrade = '';
    var errorMsg = 'You must provide at least 5 subjects each of Grade_Checking 11&12';

    for (var i = 1; i <= 25; i++) {
        ushsgrade = 'ctl00_CPH_EduQualification_USHSPreGrade_DDL' + i;
        if (document.getElementById(ushsgrade).value == '')
            break;
        else
            USHSGradeCompare.push(document.getElementById(ushsgrade).value);
    }
    USHSGradeCompare.sort(sortNumber);

    for (var i = 1; i <= 15; i++) {
        ushsnlgrade = 'ctl00_CPH_EduQualification_USHSPreNLGrade_DDL' + i;
        if (document.getElementById(ushsnlgrade).value == '')
            break;
        else
            USHSNLGradeCompare.push(document.getElementById(ushsnlgrade).value);
    }
    USHSNLGradeCompare.sort(sortNumber);

    for (var i = 0; i < USHSGradeCompare.length; i++) {
        if (USHSGradeCompare[i] == '11')
            GradeCount11++;
        else
            GradeCount12++;
    }

    for (var i = 0; i < USHSNLGradeCompare.length; i++) {
        if (USHSNLGradeCompare[i] == '11')
            GradeCount11++;
        else
            GradeCount12++;
    }
    if (GradeCount11 < 5 || GradeCount12 < 5) {
        document.getElementById(Panel3 + prmErr).value = "You must provide at least 5 subjects each of Grade_Checking 11&12"
        return "SubError";
    }
    else {
        if (CheckSubMarksObtMax("USHSPreExYear_TXT", "USHSPreSubject_DDL", "USHSPreGradeObt_TXT", "G11S1_EMsg", USHSGradeCompare.length) == "SubError") {
            return "SubError";
        }
        if (CheckSubMarksObtMax("USHSPreSubject_DDL", "USHSPreGradeObt_TXT", "USHSPreMaxMarks_TXT", "G11S1_EMsg", USHSGradeCompare.length) == "SubError") {
            return "SubError";
        }
        if (CheckSubMarksObtMax("USHSPreNLExYear_TXT", "USHSPreNLSubject_TXT", "USHSPreNLGradeObt_TXT", "G11S1_EMsg", USHSNLGradeCompare.length) == "SubError") {
            return "SubError";
        }
        if (CheckSubMarksObtMax("USHSPreNLSubject_TXT", "USHSPreNLGradeObt_TXT", "USHSPreNLMaxMarks_TXT", "G11S1_EMsg", USHSNLGradeCompare.length) == "SubError") {
            return "SubError";
        }
    }
}
/////----------- End USHSEduField----------------
//////******************************************************************************************
//////------------- Start SMUEduField----------------
function SMUEduField() {
    var SMUAcadStatus = document.getElementById(Panel3 + "AcademicStatus_DDL").value;
    if (SMUAcadStatus == "") {
        return "Ref_Field";
    }
    else if (SMUAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_REV").style.display != 'none') {
            alert("* Results available format is not correct!");
            return "Error";
        }
    }
    var SMUFinalExYr = document.getElementById(Panel3 + "SMAFinalExYr_TXT").value;
    var SMUProgramme = document.getElementById(Panel3 + "Programme_DDL").value;
    var SMUAccelProg = document.getElementById(Panel3 + "AccelProgram_DDL").value;
    var SMUSchName = document.getElementById(Panel3 + "SekolahName_DDL").value;
    if (SMUFinalExYr == "" || SMUProgramme == "" || SMUAccelProg == "" || SMUSchName == "") {
        return "Ref_Field";
    }
    if (SMUSchName == "OTH") {
        if (document.getElementById(Panel3 + "OthSchName_TXT").value == "" || document.getElementById(Panel3 + "OthSchAdd_TXT").value == "") {
            return "Ref_Field";
        }
    }
    if (SMUAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_TXT").value == "") {
            return "Ref_Field";
        }
        var K1S1Date = document.getElementById(Panel3 + "K1S1_Date_TXT").value;
        var K1S2Date = document.getElementById(Panel3 + "K1S2_Date_TXT").value;
        var K2S1Date = document.getElementById(Panel3 + "K2S1_Date_TXT").value;
        var K2S2Date = document.getElementById(Panel3 + "K2S2_Date_TXT").value;
        if (K1S1Date == "" || K1S2Date == "" || K2S1Date == "" || K2S2Date == "") {
            return "Ref_Field";
        }
        var K1S1Marks = CheckSMUMarks("K1S1");
        if (K1S1Marks == "SubError") {
            RFeild3 = 1;
        }
        var K1S2Marks = CheckSMUMarks("K1S2");
        if (K1S2Marks == "SubError") {
            RFeild3 = 1;
        }
        var K2S1Marks = CheckSMUMarks("K2S1");
        if (K2S1Marks == "SubError") {
            RFeild3 = 1;
        }
        var K2S2Marks = CheckSMUMarks("K2S2");
        if (K2S2Marks == "SubError") {
            RFeild3 = 1;
        }
    }
    else if (SMUAcadStatus == "2" || SMUAcadStatus == "3") {
        if (SMUAcadStatus == "2") {
            var SMUUniName = document.getElementById(Panel3 + "CurUniName_TXT").value;
            var SMUCurProg = document.getElementById(Panel3 + "CurProg_TXT").value;
            var SMUYrStudy = document.getElementById(Panel3 + "CurYrStudy_TXT").value;
            if (SMUUniName == "" || SMUCurProg == "" || SMUYrStudy == "") {
                return "Ref_Field";
            }


            if (document.getElementById(Panel3 + "UNUS_Date_TXT").value == "") {
                return "Ref_Field";
            }

        }
        if (SMUAcadStatus == "3") {
            var SMUCompHSCur = document.getElementById(Panel3 + "CompHSCur_TXT").value;
            var SMUHighQualf = document.getElementById(Panel3 + "HSHighQualif_TXT").value;
            if (SMUCompHSCur == "" || SMUHighQualf == "") {
                return "Ref_Field";
            }

            if (document.getElementById(Panel3 + "UNUS_Date_TXT").value == "") {
                return "Ref_Field";
            }
        }

        var UNUSMarks = CheckSMUMarks("UNUS");
        if (UNUSMarks == "SubError") {
            RFeild3 = 1;
        }
    }
    if (RFeild3 == 1) {
        return "SubError";
    }
    else {
        return "Validated";
    }
}


/////----------- End SMUEduField----------------
//////******************************************************************************************
//////------------- Start IBEduField----------------
function IBEduField() {
    var IBAcadStatus = document.getElementById(Panel3 + "AcademicStatus_DDL").value;
    var IBProgramme = document.getElementById(Panel3 + "Programme_DDL").value;
    var IBHSchool = document.getElementById(Panel3 + "HSchName_DDL").value;

    if (IBAcadStatus == "") {
        return "Ref_Field";
    }
    if (IBAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_REV").style.display == 'block') {
            alert("* Results available format is incorrect!");
            return "Error";
        }
    }

    if (document.getElementById(Panel3 + "MOEScholar_PL").className != 'hide_ctl') {
        var MOEScholar = document.getElementById(Panel3 + "UC_MOEScholar1_MOEScholar_DDL").value;
        if (MOEScholar == "") {
            return "Ref_Field";
        }
    }

    if (IBProgramme == "" || IBHSchool == "") {
        return "Ref_Field";
    }
    if (IBHSchool == "OTH") {
        var IBOthSName = document.getElementById(Panel3 + "OthSchName_TXT").value;
        var IBOthSAdd = document.getElementById(Panel3 + "OthSchAdd_TXT").value;
        var IBOthCountry = document.getElementById(Panel3 + "OthSchCountry_TXT").value;
        if (IBOthSName == "" || IBOthSAdd == "" || IBOthCountry == "") {
            return "Ref_Field";
        }
    }
    RFeild3 = 0;
    if (IBAcadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_TXT").value == "") {
            return "Ref_Field";
        }
        if (document.getElementById(Panel3 + "PreExResult_PL").style.display == 'block') {
            
            if (document.getElementById(Panel3 + "PreFinalExDate_TXT").value == "") {
                return "Ref_Field";
            }
            var PreSub = CheckFirstNSub("PreSubTaken_DDL", 12, "PreNLSubTaken_TXT", 5, "Pre_EMsg", 6);

            if (PreSub == "SubError") {
                RFeild3 = 1;
            }
            else {
                var PreSubAll = CheckSubMarksObtMaxLevel("PreSubTaken_DDL", "PreMarksObt_TXT", "PreMaxMarks_TXT", "PreLevel_DDL", "Pre_EMsg", 12)
                if (PreSubAll == "SubError") {
                    RFeild3 = 1;
                }
                else {
                    var NlPreSubAll = CheckSubMarksObtMaxLevel("PreNLSubTaken_TXT", "PreNLMarksObt_TXT", "PreNLMaxMarks_TXT", "PreNLLevel_DDL", "Pre_EMsg", 5)
                    if (NlPreSubAll == "SubError") {
                        RFeild3 = 1;
                    }
                }
            }
        }
        else {
            if (document.getElementById(Panel3 + "DipExResult_PL").style.display == 'block') {
                var DipSub = CheckFirstNSub("DipSubTaken_DDL", 12, "DipNLSubTaken_TXT", 5, "Dip_EMsg", 7);
                if (DipSub == "SubError") {
                    RFeild3 = 1;
                }
                else {
                    var DipSubAll = CheckSubMarksObtMaxLevel("DipSubTaken_DDL", "DipMarksObt_TXT", "DipMaxMarks_TXT", "DipLevel_DDL", "Dip_EMsg", 12)
                    if (DipSubAll == "SubError") {
                        RFeild3 = 1;
                    }
                    else {
                        var NlDipSubAll = CheckSubMarksObtMaxLevel("DipNLSubTaken_TXT", "DipNLMarksObt_TXT", "DipNLMaxMarks_TXT", "DipNLLevel_DDL", "Dip_EMsg", 5)
                        if (NlDipSubAll == "SubError") {
                            RFeild3 = 1;
                        }
                    }
                }
            }
            //else
            //{
            //RtnEdu = "Validated";
            //  return "Validated";
            //}
        }

    }
    else if (IBAcadStatus == "2" || IBAcadStatus == "3") {
        if (IBAcadStatus == "2") {
            var IBUniName = document.getElementById(Panel3 + "CurUniName_TXT").value;
            var IBCurProg = document.getElementById(Panel3 + "CurProg_TXT").value;
            var IBYrStudy = document.getElementById(Panel3 + "CurYrStudy_TXT").value;
            if (IBUniName == "" || IBCurProg == "" || IBYrStudy == "") {
                return "Ref_Field";
            }
        }
        if (IBAcadStatus == "3") {
            var IBCompHSCur = document.getElementById(Panel3 + "CompHSCur_TXT").value;
            var IBHighQualf = document.getElementById(Panel3 + "HSHighQualif_TXT").value;
            if (IBCompHSCur == "" || IBHighQualf == "") {
                return "Ref_Field";
            }
        }
        var IBEssay = document.getElementById(Panel3 + "EssayGd_DDL").value;
        var IBTheory = document.getElementById(Panel3 + "TheoryGd_DDL").value;
        if (IBEssay == "" || IBTheory == "") {
            return "Ref_Field";
        }

        var DipSub = CheckFirstNSub("DipSubTaken_DDL", 12, "DipNLSubTaken_TXT", 5, "Dip_EMsg", 7);
        if (DipSub == "SubError") {
            RFeild3 = 1;
        }
        else {
            var DipSubAll = CheckSubMarksObtMaxLevel("DipSubTaken_DDL", "DipMarksObt_TXT", "DipMaxMarks_TXT", "DipLevel_DDL", "Dip_EMsg", 12)
            if (DipSubAll == "SubError") {
                RFeild3 = 1;
            }
            else {
                var NlDipSubAll = CheckSubMarksObtMaxLevel("DipNLSubTaken_TXT", "DipNLMarksObt_TXT", "DipNLMaxMarks_TXT", "DipNLLevel_DDL", "Dip_EMsg", 5)
                if (NlDipSubAll == "SubError") {
                    RFeild3 = 1;
                }
            }
        }
    }
    if (document.getElementById(Panel3 + "PhySubHSchool_DDL").value == "") {
        return "Ref_Field";
    }
    if (RFeild3 == 1) {
        return "SubError";
    }
    else {
        return "Validated";
    }
}
/////----------- End IBEduField----------------
//////******************************************************************************************

//////------------- Start PRCEduField----------------

function PRCEduField() {
    var PRCAcadStatus = document.getElementById(Panel3 + "AcademicStatus_DDL").value;
//    var PRCAppThrAgent = document.getElementById(Panel3 + "AppThrAgent_DDL").value;
     var PRCSMHSchool = document.getElementById(Panel3 + "SMHSchool_DDL").value;
    var PRCProgramme = document.getElementById(Panel3 + "Programme_DDL").value;
    if (PRCAcadStatus == "") {
        return "Ref_Field";
    }
    if (PRCAcadStatus == "1") {
        document.getElementById(Panel3 + "SMTerm_11_EMsg").value = "";
        document.getElementById(Panel3 + "SMTerm_12_EMsg").value = "";
        document.getElementById(Panel3 + "SMTerm_21_EMsg").value = "";
        document.getElementById(Panel3 + "SMTerm_22_EMsg").value = "";
        document.getElementById(Panel3 + "Sub_EMsg").value = "";
        if (document.getElementById(Panel3 + "ResultsAvail_REV").style.display != 'none') {
            alert("* Results available format is not correct!");
            return "Error";
        }
    }

    if (PRCAcadStatus == "" || PRCSMHSchool == "" || PRCProgramme == "") {
        return "Ref_Field";
    }
//    if (PRCAppThrAgent == "Y") {
//        if (document.getElementById(Panel3 + "AgentName_DDL").value == "") {
//            return "Ref_Field";
//        }
//    }
    if (PRCSMHSchool == "OTH") {
        var PRCOthSName = document.getElementById(Panel3 + "OthSchName_TXT").value;
        var PRCOthSAdd = document.getElementById(Panel3 + "OthSchAdd_TXT").value;
        var PRCOthCountry = document.getElementById(Panel3 + "OthSchCountry_TXT").value;
        if (PRCOthSName == "" || PRCOthSAdd == "" || PRCOthCountry == "") {
            return "Ref_Field";
        }
    }
    if (PRCAcadStatus == "1") {
        var RequiredFields3_Ary = new Array();
        RequiredFields3_Ary[0] = Panel3 + "ResultsAvail_TXT";
        RequiredFields3_Ary[1] = Panel3 + "SMEYear_11_TXT";
        RequiredFields3_Ary[2] = Panel3 + "SMEYear_12_TXT";
        RequiredFields3_Ary[3] = Panel3 + "SMEYear_21_TXT";
        RequiredFields3_Ary[4] = Panel3 + "SMEYear_22_TXT";
        RequiredFields3_Ary[5] = Panel3 + "SubExamYr_TXT";
        RequiredFields3_Ary[6] = Panel3 + "SubProvince_DDL";
        for (j = 0; j <= RequiredFields3_Ary.length - 1; j++) {
            var Fields_AryValue = document.getElementById(RequiredFields3_Ary[j]).value;
            if (Fields_AryValue == "") {
                return "Ref_Field";
            }
        }
        RFeild3 = 0;
        var Rtn11Sub3 = CheckFirstThreeSub("SMSub_11_DDL", "SMTerm_11_EMsg");
        if (Rtn11Sub3 == "SubError") {
            RFeild3 = 1;
        }
        else {
            var Rtn11All = CheckSubMarksObtMax("SMSub_11_DDL", "SMMarksObt_11_TXT", "SMMaxMarks_11_TXT", "SMTerm_11_EMsg", 10);
            if (Rtn11All == "SubError") {
                RFeild3 = 1;
            }
        }
        var Rtn12Sub3 = CheckFirstThreeSub("SMSub_12_DDL", "SMTerm_12_EMsg");
        if (Rtn12Sub3 == "SubError") {
            RFeild3 = 1;
        }
        else {
            var Rtn12All = CheckSubMarksObtMax("SMSub_12_DDL", "SMMarksObt_12_TXT", "SMMaxMarks_12_TXT", "SMTerm_12_EMsg", 10);
            if (Rtn12All == "SubError") {
                RFeild3 = 1;
            }
        }
        var Rtn21Sub3 = CheckFirstThreeSub("SMSub_21_DDL", "SMTerm_21_EMsg");
        if (Rtn21Sub3 == "SubError") {
            RFeild3 = 1;
        }
        else {
            var Rtn21All = CheckSubMarksObtMax("SMSub_21_DDL", "SMMarksObt_21_TXT", "SMMaxMarks_21_TXT", "SMTerm_21_EMsg", 10);
            if (Rtn21All == "SubError") {
                RFeild3 = 1;
            }
        }
        var Rtn22Sub3 = CheckFirstThreeSub("SMSub_22_DDL", "SMTerm_22_EMsg");
        if (Rtn22Sub3 == "SubError") {
            RFeild3 = 1;
        }
        else {
            var Rtn22All = CheckSubMarksObtMax("SMSub_22_DDL", "SMMarksObt_22_TXT", "SMMaxMarks_22_TXT", "SMTerm_22_EMsg", 10);
            if (Rtn22All == "SubError") {
                RFeild3 = 1;
            }
        }
        var RtnGaoKaoSub = CheckFirstThreeSub("GaoKaoSubTaken_DDL", "Sub_EMsg");
        if (RtnGaoKaoSub == "SubError") {
            RFeild3 = 1;
        }
 

        if (RFeild3 == 1) {
            return "SubError";
        }
        else {
            return "Validated";
        }
    }
    else if (PRCAcadStatus == "2" || PRCAcadStatus == "3") {
        if (PRCAcadStatus == "2") {
            var PrcUniName = document.getElementById(Panel3 + "CurUniName_TXT").value;
            var PrcCurProg = document.getElementById(Panel3 + "CurProg_TXT").value;
            var PrcYrStudy = document.getElementById(Panel3 + "CurYrStudy_TXT").value;
            if (PrcUniName == "" || PrcCurProg == "" || PrcYrStudy == "") {
                return "Ref_Field";
            }
        }
        if (PRCAcadStatus == "3") {
            var PrcCompHSCur = document.getElementById(Panel3 + "CompHSCur_TXT").value;
            var PrcHighQualf = document.getElementById(Panel3 + "HSHighQualif_TXT").value;
            if (PrcCompHSCur == "" || PrcHighQualf == "") {
                return "Ref_Field";
            }
        }

        if (document.getElementById(Panel3 + "ResultExamYear_TXT").value == "" || document.getElementById(Panel3 + "ResultProvince_DDL").value == "") {
            return "Ref_Field";
        }
        var RtnGaoKao = CheckFirstThreeSub("GaoKaoSubject_DDL", "Result_EMsg");
        if (RtnGaoKao == "SubError") {
            RFeild3 = 1;
        }
        else {
            var RtnGaoKaoFive = CheckSubMarksObtMax("GaoKaoSubject_DDL", "GaoKaoMarksObt_TXT", "GaoKaoMaxMarks_TXT", "Result_EMsg", 10);
            if (RtnGaoKaoFive == "SubError") {
                RFeild3 = 1;
            }
        }
        if (document.getElementById(Panel3 + "EngYr_TXT").value != "") {

            if (document.getElementById(Panel3 + "EngGd_TXT").value == "") {
                return "Ref_Field";
            }
        }
        if (document.getElementById(Panel3 + "MathsYr_TXT").value != "") {

            if (document.getElementById(Panel3 + "MathsGd_TXT").value == "") {
                return "Ref_Field";
            }
        }
        if (document.getElementById(Panel3 + "PhysicsYr_TXT").value != "") {

            if (document.getElementById(Panel3 + "PhysicsGd_TXT").value == "") {
                return "Ref_Field";
            }
        }
        if (document.getElementById(Panel3 + "EconomicsYr_TXT").value != "") {

            if (document.getElementById(Panel3 + "EconomicsGd_TXT").value == "") {
                return "Ref_Field";
            }
        }
        if (RFeild3 == 1) {
            return "SubError";
        }
        else {
            return "Validated";
        }
    }
}
/////----------- End PRCEduField----------------
//////******************************************************************************************
//////------------- Start SM2EduField----------------

function SM2EduField() {

    var SM2SMHSchool = document.getElementById(Panel3 + "SMHSchool_DDL").value;
    var SM2BridgMatric = document.getElementById(Panel3 + "txtBridgMatric").value;

    if (SM2SMHSchool == "" || SM2BridgMatric == "") {
        return "Ref_Field";
    }
    if (SM2SMHSchool == "OTH") {
        var SM2OthSName = document.getElementById(Panel3 + "OthSchName_TXT").value;
        var SM2OthSAdd = document.getElementById(Panel3 + "OthSchAdd_TXT").value;
        var SM2OthCountry = document.getElementById(Panel3 + "OthSchCountry_TXT").value;
        if (SM2OthSName == "" || SM2OthSAdd == "" || SM2OthCountry == "") {
            return "Ref_Field";
        }
    }
    return "Validated";
}
/////----------- End SM2EduField----------------
//////******************************************************************************************
//////------------- Start NUSHSEduField----------------

function NUSHSEduField() {
    var nushscadStatus = document.getElementById(Panel3 + "AcademicStatus_DDL").value;
    if (nushscadStatus == "") {
        return "Ref_Field";
    }
    else if (nushscadStatus == "1") {
        if (document.getElementById(Panel3 + "ResultsAvail_REV").style.display != 'none') {
            alert("* Results available format is not correct!");
            return "Error";
        }
    }
    var ListGrade = document.getElementById(Panel3 + "ddListReachGrade").value;
    if (ListGrade == "") {
        return "Ref_Field";
    }
    if (document.getElementById(Panel3 + "CapExamYear_TXT").value == "" || document.getElementById(Panel3 + "CapGraduation_TXT").value == "") {
        return "Ref_Field";
    }
    if (document.getElementById(Panel3 + "MotherTongueSubject_TXT").value == "" || document.getElementById(Panel3 + "txtReachTitle").value == "") {
        return "Ref_Field";
    }
    if (document.getElementById(Panel3 + "MOEScholar_PL").className != 'hide_ctl') {
        var MOEScholar = document.getElementById(Panel3 + "UC_MOEScholar1_MOEScholar_DDL").value;
        if (MOEScholar == "") {
            return "Ref_Field";
        }
    }

    RFeild3 = 0;
    var Major = CheckFirstNSub("MajorSubTaken_DDL", 5, "MajorSubNL_TXT", 2, "Major_EMsg", 3);
    if (Major == "SubError") {
        RFeild3 = 1;
    }
    else {
        Major = CheckSubCap("MajorSubTaken_DDL", "MajorCap_TXT", "Major_EMsg", 5);
        if (Major == "SubError") {
            RFeild3 = 1;
        }
        else {
            var MajorNL = CheckSubCap("MajorSubNL_TXT", "MajorCapNL_TXT", "Major_EMsg", 2);
            if (MajorNL == "SubError") {
                RFeild3 = 1;
            }
        }
    }

    var Honours = CheckSubCap("HonoursSubTaken_DDL", "HonoursCap_TXT", "Honours_EMsg", 4);
    if (Honours == "SubError") {
        RFeild3 = 1;
    }
    else {
        var HonoursNL = CheckSubCap("HonoursSubNL_TXT", "HonoursCapNL_TXT", "Honours_EMsg", 2);
        if (HonoursNL == "SubError") {
            RFeild3 = 1;
        }
    }

    var Overall = CheckFirstNSub("OverallSubTaken_DDL", 7, "OverallSubNL_TXT", 2, "Overall_EMsg", 5);
    if (Overall == "SubError") {
        RFeild3 = 1;
    }
    else {
        var Honours = CheckSubCap("OverallSubTaken_DDL", "OverallCap_TXT", "Overall_EMsg", 7);
        if (Honours == "SubError") {
            RFeild3 = 1;
        }
        else {
            var HonoursNL = CheckSubCap("OverallSubNL_TXT", "OverallCapNL_TXT", "Overall_EMsg", 2);
            if (HonoursNL == "SubError") {
                RFeild3 = 1;
            }
        }
    }
    if (RFeild3 == 1) {
        return "SubError";
    }
    else {
        return "Validated";
    }
}

/////----------- End NUSHSEduField --------------------
//////******************************************************************************************
function CheckFirsttwoSub(prmSubFd, ErrorId) {
    document.getElementById(Panel3 + ErrorId).value = "";
    for (i = 1; i <= 2; i++) {
        if (document.getElementById(Panel3 + prmSubFd + i).value == "") {
            if (i == 1) {
                document.getElementById(Panel3 + ErrorId).value = "* Please indicate the subjects taken.";
                return "SubError";
            }
            else {
                document.getElementById(Panel3 + ErrorId).value = "* Please indicate at least 2 subjects taken.";
                return "SubError";
            }
        }
    }
}

//////------------- Start CheckFirstNSub----------------
function CheckFirstNSub(prmSubFd, prmDDLCount, prmSubTxtFd, prmTxtCount, ErrorId, prmNumOfSub) {
    document.getElementById(Panel3 + ErrorId).value = "";
    subCount = 0;
    for (i = 1; i <= prmDDLCount; i++) {
        if (document.getElementById(Panel3 + prmSubFd + i).value != "") {
            subCount += 1;
        }
    }
    for (i = 1; i <= prmTxtCount; i++) {
        if (document.getElementById(Panel3 + prmSubTxtFd + i).value != "") {
            subCount += 1;
        }
    }
    if (subCount < prmNumOfSub) {
        if (subCount == 0) {
            document.getElementById(Panel3 + ErrorId).value = "* Please indicate the subjects taken.";
            return "SubError";
        }
        else {
            document.getElementById(Panel3 + ErrorId).value = "* Please indicate at least " + prmNumOfSub + " subjects taken.";
            return "SubError";
        }
    }
}
/////----------- End CheckFirstNSub----------------
//////******************************************************************************************

//////------------- Start CheckFirstSixSub----------------
function CheckFirstSixSub(prmSubFd, ErrorId) {
    document.getElementById(Panel3 + ErrorId).value = "";
    for (i = 1; i <= 6; i++) {
        if (document.getElementById(Panel3 + prmSubFd + i).value == "") {
            if (i == 1) {
                document.getElementById(Panel3 + ErrorId).value = "* Please indicate the subjects taken.";
                return "SubError";
            }
            else {
                document.getElementById(Panel3 + ErrorId).value = "* Please indicate at least 6 subjects taken.";
                return "SubError";
            }
        }
    }
}
/////----------- End CheckFirstSixSub----------------
//////******************************************************************************************

//////------------- Start CheckFirstThreeSub----------------
function CheckFirstThreeSub(prmSubFd, ErrorId) {
    document.getElementById(Panel3 + ErrorId).value = "";
    for (i = 1; i <= 3; i++) {
        if (document.getElementById(Panel3 + prmSubFd + i).value == "") {
            if (i == 1) {
                document.getElementById(Panel3 + ErrorId).value = "* Please indicate the subjects taken.";
                return "SubError";
            }
            else {
                document.getElementById(Panel3 + ErrorId).value = "* Please indicate at least 3 subjects taken.";
                return "SubError";
            }
        }
    }
}
/////----------- End CheckFirstThreeSub----------------
//////******************************************************************************************
//////------------- Start CheckFiveSub----------------
function CheckFiveSub(prmSubFd, prmSubTxtFd, ErrorId, prmDDLCount, prmTxtCount) {
    document.getElementById(Panel3 + ErrorId).value = "";
    subCount = 0;
    for (i = 1; i <= prmDDLCount; i++) {
        if (document.getElementById(Panel3 + prmSubFd + i).value != "") {
            subCount += 1;
        }
    }
    for (i = 1; i <= prmTxtCount; i++) {
        if (document.getElementById(Panel3 + prmSubTxtFd + i).value != "") {
            subCount += 1;
        }
    }
    if (subCount < 5) {
        if (subCount == 0) {
            document.getElementById(Panel3 + ErrorId).value = "* Please indicate the subjects taken.";
            return "SubError";
        }
        else {
            document.getElementById(Panel3 + ErrorId).value = "* Please indicate at least 5 subjects taken.";
            return "SubError";
        }
    }

}
/////----------- End CheckFiveSub----------------
//////******************************************************************************************
//////------------- Start CheckSubMarksObtMax----------------CheckAllSubMarks

function CheckSubMarksObtMax(prmSub, prmObt, prmMax, prmErr, prmCount) {
    document.getElementById(Panel3 + prmErr).value = "";
    for (j = 1; j <= prmCount; j++) {
        if (document.getElementById(Panel3 + prmSub + j).value != "") {
            if (document.getElementById(Panel3 + prmObt + j).value == "" || document.getElementById(Panel3 + prmMax + j).value == "") {
                document.getElementById(Panel3 + prmErr).value = "* Please enter Marks Obtained and Maximum Marks for the subjects entered."
                return "SubError";
            }
        }
    }
}
/////----------- End CheckSubMarksObtMax----------------
//////******************************************************************************************



//////------------- Start CheckSubCap----------------

function CheckSubCap(prmSub, prmCap, prmErr, prmCount) {
    document.getElementById(Panel3 + prmErr).value = "";
    for (k = 1; k <= prmCount; k++) {
        if (document.getElementById(Panel3 + prmSub + k).value != "" && document.getElementById(Panel3 + prmCap + k).value == "") {
            document.getElementById(Panel3 + prmErr).value = "* Please enter CAP for the given subjects";
            return "SubError";
        }
    }
}
/////----------- End CheckSubCap----------------
//////******************************************************************************************
//////------------- Start CheckSubMarks----------------

function CheckSubMarks(prmSub, prmMarks, prmErr, prmCount) {
    document.getElementById(Panel3 + prmErr).value = "";
    for (k = 1; k <= prmCount; k++) {
        if (document.getElementById(Panel3 + prmSub + k).value != "" && document.getElementById(Panel3 + prmMarks + k).value == "") {
            document.getElementById(Panel3 + prmErr).value = "* Please enter Marks for the given subjects";
            return "SubError";
        }
    }
}

/////----------- End CheckSubMarks----------------
//////******************************************************************************************
//////------------- Start CheckSubMarksObtMaxLevel----------------

function CheckSubMarksObtMaxLevel(prmSub, prmObt, prmMax, prmLvl, prmErr, prmCount) {
    document.getElementById(Panel3 + prmErr).value = "";
    for (j = 1; j <= prmCount; j++) {
        if (document.getElementById(Panel3 + prmSub + j).value != "") {
            if (document.getElementById(Panel3 + prmObt + j).value == "" || document.getElementById(Panel3 + prmMax + j).value == "" || document.getElementById(Panel3 + prmLvl + j).value == "") {
                document.getElementById(Panel3 + prmErr).value = "* Please enter Grade Obtained , Best Grade and Level for the subjects entered."
                return "SubError";
            }
        }
    }
}
/////----------- End CheckSubMarksObtMaxLevel----------------
//////******************************************************************************************
//////------------- Start CheckSMUMarks----------------

function CheckSMUMarks(prmType) {
    document.getElementById(Panel3 + prmType + "_EMsg").value = "";
    var Rcount = document.getElementById(Panel3 + prmType + "_Count_HF").value;
    var flag = parseInt(0);
    var n = parseInt(1);
    var Gvr;
    for (i = 1; i <= Rcount; i++) {
        var id = i + 1;
        if (id > 9) {
            Gvr = "_GV_ctl" + id;
        }
        else {
            Gvr = "_GV_ctl0" + id;
        }
        var SMUMarks = document.getElementById(Panel3 + prmType + Gvr + "_" + prmType + "_Marks_TXT").value;
        if (SMUMarks != "") {
            flag = flag + n;
        }
    }

    if (flag < 6) {
        document.getElementById(Panel3 + prmType + "_EMsg").value = "* Please enter Marks for 6 subjects.";
        return "SubError";
    }
}
/////----------- End CheckSMUMarks----------------
//////******************************************************************************************
//////------------- Start OthersEdu----------------
//function CheckOthersEdu(prmSub,prmObt,prmMax,prmLvl,prmErr,prmCount,prmHSQ )
function CheckOthersEdu(prmSub, prmObt, prmMax, prmErr, prmCount, prmHSQ) {
    document.getElementById(Panel3 + prmErr).value = "";
    for (M = 1; M <= prmCount; M++) {
        var OthSub = document.getElementById(Panel3 + prmSub + M).value;
        var OthMObt = document.getElementById(Panel3 + prmObt + M).value;
        var OthMaxM = document.getElementById(Panel3 + prmMax + M).value;
        //var OthLvl = document.getElementById(Panel3 + prmLvl +M).value;
        if (OthSub != "") {
            if (OthMObt == "" || OthMaxM == "") {
                document.getElementById(Panel3 + prmErr).value = "* Please enter Grade Obtained and Best Grade for the subjects entered."
                return "SubError";
            }
            if (prmHSQ == "74" || prmHSQ == "86" || prmHSQ == "A0" || prmHSQ == "70" || prmHSQ == "75" || prmHSQ == "84" || prmHSQ == "7A") {
                /*if(OthLvl == "")
                {
                document.getElementById(Panel3 + prmErr).value = "* Please enter Level for the subjects entered."
                return "SubError";
                }*/
            }
        }
    }
}
/////----------- End OthersEdu---------------- 
//////******************************************************************************************
//////------------- Start USTPMEdu----------------
function CheckUSTPMEdu(prmSub, prmObt, prmMax, prmLvl, prmErr, prmCount, prmHSQ) {
    document.getElementById(Panel3 + prmErr).value = "";
    for (M = 1; M <= prmCount; M++) {
        var OthSub = document.getElementById(Panel3 + prmSub + M).value;
        var OthMObt = document.getElementById(Panel3 + prmObt + M).value;
        var OthMaxM = document.getElementById(Panel3 + prmMax + M).value;
        var OthLvl = document.getElementById(Panel3 + prmLvl + M).value;
        if (OthSub != "") {
            if (OthMObt == "" || OthMaxM == "") {
                document.getElementById(Panel3 + prmErr).value = "* Please enter Grade Obtained and Best Grade for the subjects entered."
                return "SubError";
            }
            if (prmHSQ == "7A") {
                if (OthLvl == "") {
                    document.getElementById(Panel3 + prmErr).value = "* Please enter Level for the subjects entered."
                    return "SubError";
                }
            }
        }
    }
}
/////----------- End USTPMEdu---------------- 
//////******************************************************************************************
