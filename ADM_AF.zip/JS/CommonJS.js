﻿
var CPH = "ctl00_CPH_";
var CVPanel1 = CPH + "PersonalInfo_";

function PrintOpen() {
    window.print();
    return false;
}
/////*************XXXXXXXX************////
function TextAreaLimit(Object, output, MaxLen, Maxcount) {
    var content = Object.value;
    var word_array = null;
    var num_words = 0;
    if (content != "") {
        word_array = content.match(/\b\w+\b/g);
    }
    if (word_array == null) {
        num_words = 0;
    }
    else {
        num_words = word_array.length;
    }
    var vale = MaxLen - num_words;

    if (num_words > MaxLen || content.length > Maxcount) {
        alert("You have exceeded " + MaxLen + " words!");
        Object.value = Object.value.substring(0, Maxcount);
        document.getElementById(output).value = 0;
        return false;
        Object.focus();
    }
    else {
        if (document.getElementById(output).value != 0) {
            document.getElementById(output).value = vale;
        }
        return true;
    }
}


/////*************XXXXXXXX************//// 

function CheckAddressfist_TXT(AddText) {
    var Address1_id = AddText.id.substring(0, AddText.id.length - 1);
    var Address1 = document.getElementById(Address1_id + 1).value;
    if (Address1 == "") {
        alert("Please Provide the Address (Line 1).");
        document.getElementById(AddText.id).value = "";
    }
}
/////*************Show year  - 12************////
function onCalendarShown(sender, e) {
    var cal = $find("CalendarExtender1");     //Setting the default mode to month 

    sender._switchMode("years", true); //Iterate every month Item and attach click event to it 
    if (sender._monthsBody) {
        for (var i = 0; i < sender._monthsBody.rows.length; i++) {
            var row = sender._monthsBody.rows[i];
            for (var j = 0; j < row.cells.length; j++) {
                Sys.UI.DomEvent.addHandler(row.cells[j].firstChild, "click", call);
            }
        }
    }

}
function onCalendarHidden(sender, e) {
    var cal = $find("CalendarExtender1");     //Iterate every month Item and remove click event from it
    if (sender._monthsBody) {
        for (var i = 0; i < sender._monthsBody.rows.length; i++) {
            var row = sender._monthsBody.rows[i];
            for (var j = 0; j < row.cells.length; j++) {
                Sys.UI.DomEvent.removeHandler(row.cells[j].firstChild, "click", call);
            }
        }
    }
}
function call(eventElement) {
    var target = eventElement.target;
    switch (target.mode) {
        case "month":
            var TagId = target.id;
            var arry = TagId.split("_");

            var cal = $find("ctl00_CPH_" + arry[2] + "_" + arry[3]);
            cal._visibleDate = target.date;
            cal.set_selectedDate(target.date);
            cal._switchMonth(target.date);
            cal._blur.post(true);
            cal.raiseDateSelectionChanged();
            break;
    }
}

/////*************Show year  - 12************////
function CalendarShown(sender, e) {
    sender._textbox._element.value = "";
    var today = new Date();
    today.setYear(today.getYear() - 12);
    var date12 = today.format("dd-MMM-yyyy");
    sender._textbox._element.value = date12;
    sender._switchMode("years", true);
    sender._textbox._element.value = "";
}

/////*************Check year -17************//// -----Sumathi
function CheckDate(sender, args) {
    var todate = new Date();
    todate.setYear(todate.getFullYear() - 12);
    //todate.setYear(todate.getFullYear()-17);
    var dsf = sender._selectedDate.format("dd-MMM-yyyy");
    if (sender._selectedDate > todate) {
        alert("* Your age must be at least 12 years to apply please check the Date of Birth!");
        // set the date back to the current date
        sender._textbox.set_Value("");
    }
};

function CheckResultDate(sender, args) {

    var abc = new Date(sender._selectedDate);
    var date1 = new Date().calcFullMonths(3)
    var date2 = new Date().calcFullMonths(-3)
    if (abc < date1 || abc > date2) {
        alert("* Date Invalid");
    }

};
Date.prototype.calcFullMonths = function(monthOffset) {

    var dt = new Date(this);
    dt.setMonth(dt.getMonth() + monthOffset);
    return dt;
};

/////*************XXXXXXXX************////
function divbg_mouseout(Img_bg) {
    var aaa, bbb;
    aaa = "ctl00_" + Img_bg;
    var val = document.getElementById("ctl00_NavPl_HF").value;
    bbb = "ctl00_" + val;
    if (aaa != bbb)
        document.getElementById("ctl00_" + Img_bg).style.backgroundImage = "url(../Images/navbar-Grey.gif)";
}


/////*************XXXXXXXX************////
function divbg_mouseover(Img_bg) {
    var aaa, bbb;
    aaa = "ctl00_navdiv" + Img_bg;
    var val = document.getElementById("ctl00_NavPl_HF").value;
    bbb = "ctl00_navdiv" + val;
    if (aaa != bbb)
        document.getElementById("ctl00_" + Img_bg).style.backgroundImage = "url(../Images/navbar-Yellow.gif)";
}

/////*************XXXXXXXX************////
function poptastic(url) {
    var pickwindow;
    pickwindow = window.open(url, 'Printpage', 'left=50,top=0,height=600,width=850,menubar=yes,depedent=no,scrollbars=yes,status=no');
    pickwindow.focus();
}
/////*************XXXXXXXX************////
function SubjectChoices_DDL(SelSub_DDL, ddlcount, selectddl) {
    var Checkval, SubddlID, id, subid, Icount;
    Icount = parseInt(ddlcount);
    var Vflag = 0;
    id = SelSub_DDL.id;
    if (selectddl > 9) {
        subid = id.substring(0, id.length - 2);
    }
    else {
        subid = id.substring(0, id.length - 1);
    }

    var Choicesddlval = SelSub_DDL.options[SelSub_DDL.selectedIndex].value;

    var subject_DDL1 = subid + "1";
    Firstselectedval = document.getElementById(subject_DDL1).value;
    if (id != subject_DDL1 && Firstselectedval == "") {
        alert("Your First Choice of Subject is missing.");
        document.getElementById(id).selectedIndex = 0;
    }
    else {

        for (i = 1; i <= Icount; i++) {
            SubddlID = subid + i;
            if (document.getElementById(SubddlID).selectedIndex != 0) {
                Checkval = document.getElementById(SubddlID).value;
                if (Choicesddlval == Checkval && id != SubddlID) {
                    alert("All Subject Chosen must be unique (no duplicaton).");
                    document.getElementById(id).selectedIndex = 0;
                }
            }
        }
    }
}


/////*************XXXXXXXX************////
function ProgramChoices(ddlselected) {
    var checkddlval, progddlID, id, subid, PrgChoice_DDL1, Cnt;
    var Errorfield, Errorfieldval, Choicesddlval, Firstselectedval;
    var Vflag = 0;
    id = ddlselected.id;

    subid = id.substring(0, id.length - 1);
    PrgChoice_DDL1 = subid + "1";
    Choicesddlval = ddlselected.options[ddlselected.selectedIndex].value;
    Firstselectedval = document.getElementById(PrgChoice_DDL1).value;
    //    if (Firstselectedval == "24U:000") { Done for REP;
    //        Cnt = 3;
    //      
    //    }
    //    else {
    //        Cnt = 5;
    //      
    //    }
    if (id != PrgChoice_DDL1 && Firstselectedval == "") {
        alert("Your First Choice of Programme is missing.");
        document.getElementById(id).selectedIndex = 0;

    }
    else {
        for (i = 1; i <= 5; i++) {
            progddlID = subid + i;
            //               var item = document.getElementById(progddlID);
            //               if (item!=null) { Done for REP
            if (document.getElementById(progddlID).selectedIndex != 0) {
                checkddlval = document.getElementById(progddlID).value;
                if (Choicesddlval == checkddlval && id != progddlID) {
                    alert("All Choices Of NTU Programme must be unique.");
                    document.getElementById(id).selectedIndex = 0;
                }

                var ChoicesddlvalPair = Choicesddlval.split(':');
                var checkddlvalPair = checkddlval.split(':');
                if ((ChoicesddlvalPair[1] != 0000) && (checkddlvalPair[1] != 0000)) {
                    if (ChoicesddlvalPair[1] == checkddlvalPair[1] && id != progddlID) {
                        alert("This step is not acceptable, please click on the Information icon next to the 1st Choice for more information.");
                        document.getElementById(id).selectedIndex = 0;
                    }
                }

            }
            // }
        }
    }
}

/////*************XXXXXXXX************////
function imgmouseover(Img_bg, Image_type) {
    document.getElementById(Img_bg.id).src = Image_type;
}
function imgmouseoversub(Img_bg, Image_type) {
    document.getElementById(Img_bg).src = Image_type;
}
/////*************XXXXXXXX************////
function checklength(Sel_text) {
    var sel_text_id = Sel_text.id;
    document.getElementById(sel_text_id + "EMsg").innerHTML = "";
    var text_val = document.getElementById(sel_text_id).value;
    if (text_val != 0) {
        //if (text_val.length < 8) {
        //    document.getElementById(sel_text_id + "EMsg").innerHTML = "* Password must be between 8 to 20 Characters";
        //    return false;
        //    sel_text_id.focus();
        //}

        //Only allow this character !@#$%&()*
        var regExp = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%&()*]).{8,}/;

        var validPassword = regExp.test(text_val);

        //alert(validPassword);
        
        if (validPassword == false) {
            document.getElementById(sel_text_id + "EMsg").innerHTML = "* Password does not meet the requirements!";
        }
        return validPassword;
    }
}

/////*************check geder and title***********////// 
function CheckGender(prmField) {
    var prmField_id = prmField.id;
    var title = document.getElementById(CVPanel1 + "Title_DDL").value;
    var gender = document.getElementById(CVPanel1 + "Gender_DDL").value;

    if (title != "" && gender != "") {
        if (gender == "M" && title != "04") {
            alert("* Title and Gender not matching.");
            prmField.value = "";
            return false;

            prmField_id.focus();
        }
        else if (gender == "F" && title != "05" && title != "07") {
            alert("* Title and Gender not matching.");
            prmField.value = "";
            return false;
            prmField_id.focus();
        }
    }
}

/////*************  openwindow     ************////

function openwindow(url) {
    var openwind;
    openwind = window.open(url, 'openwin', 'left=1px, resizable= yes,scrollbars= yes, toolbar= yes, location= yes, menubar= yes,help=yes');
    if (window.focus) { openwind.focus() }

}

/*UKLevel'A' Validation Start*/
function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
}

function isAlphaNumeric(keyCode) {
    return (((keyCode >= 48 && keyCode <= 57) && isShift == false) ||

           (keyCode >= 65 && keyCode <= 90) || keyCode == 8 ||

           (keyCode >= 96 && keyCode <= 105))
}

function getFullYear() {
    var date_object = new Date();
    var year = date_object.getYear();
    if (year < 2000) {
        year = year + 1900;
    }
}
function EducationRowValidate(type, selectedrow) {
    var examYearCurrent = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + selectedrow;
    var errorMsg = 'Please fill the previous row';
    for (var i = 1; i < selectedrow; i++) {
        var examYearPrevious = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        var subjectChosen = 'ctl00_CPH_EduQualification_' + type + 'SubTaken_DDL' + i;
        var GradeObt = 'ctl00_CPH_EduQualification_' + type + 'GradeObt_TXT' + i;
        var BestGrade = 'ctl00_CPH_EduQualification_' + type + 'BestGrade_TXT' + i;
        var MarksObt = 'ctl00_CPH_EduQualification_' + type + 'MarksObt_TXT' + i;
        var MaxMarks = 'ctl00_CPH_EduQualification_' + type + 'MaxMarks_TXT' + i;
        var LevelChosen = 'ctl00_CPH_EduQualification_' + type + 'Level_DDL' + i;

        if (document.getElementById(examYearPrevious).value != ''
            && document.getElementById(subjectChosen).selectedIndex != 0
            && document.getElementById(GradeObt).value != ''
            && document.getElementById(BestGrade).value != ''
            && document.getElementById(MarksObt).value != ''
            && document.getElementById(MaxMarks).value != ''
            && document.getElementById(LevelChosen).selectedIndex != 0) {
            continue;
        }
        else {

            if (document.getElementById(examYearPrevious).value == '') {
                alert(errorMsg);
                document.getElementById(examYearPrevious).focus();
            }
            else if (document.getElementById(subjectChosen).selectedIndex == 0) {
                alert(errorMsg);
                document.getElementById(subjectChosen).focus();
            }
            else if (document.getElementById(GradeObt).value == '') {
                alert(errorMsg);
                document.getElementById(GradeObt).focus();
            }
            else if (document.getElementById(BestGrade).value == '') {
                alert(errorMsg);
                document.getElementById(BestGrade).focus();
            }
            else if (document.getElementById(MarksObt).value == '' && document.getElementById(MaxMarks).value != '') {
                errorMsg = errorMsg;
                alert(errorMsg);
                document.getElementById(MarksObt).focus();
            }
            else if (document.getElementById(MaxMarks).value == '' && document.getElementById(MarksObt).value != '') {
                errorMsg = errorMsg + ' and maximum marks mandatory when marks mbtained is entered';
                alert(errorMsg);
                document.getElementById(MaxMarks).focus();
            }
            else if (document.getElementById(LevelChosen).selectedIndex == 0) {
                alert(errorMsg);
                document.getElementById(LevelChosen).focus();
            }
        }
    }
}
function EducationNLRowValidate(type, selectedrow) {
    var examYearCurrent = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + selectedrow;
    var errorMsg = 'Please fill the previous row';
    for (var i = 1; i < selectedrow; i++) {
        var examYearPrevious = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        var subjectChosen = 'ctl00_CPH_EduQualification_' + type + 'SubTaken_TXT' + i;
        var GradeObt = 'ctl00_CPH_EduQualification_' + type + 'GradeObt_TXT' + i;
        var BestGrade = 'ctl00_CPH_EduQualification_' + type + 'BestGrade_TXT' + i;
        var MarksObt = 'ctl00_CPH_EduQualification_' + type + 'MarksObt_TXT' + i;
        var MaxMarks = 'ctl00_CPH_EduQualification_' + type + 'MaxMarks_TXT' + i;
        var LevelChosen = 'ctl00_CPH_EduQualification_' + type + 'Level_DDL' + i;

        if (document.getElementById(examYearPrevious).value != ''
            && document.getElementById(subjectChosen).value != ''
            && document.getElementById(GradeObt).value != ''
            && document.getElementById(BestGrade).value != ''
            && document.getElementById(MarksObt).value != ''
            && document.getElementById(MaxMarks).value != ''
            && document.getElementById(LevelChosen).selectedIndex != 0) {
            continue;
        }
        else {

            if (document.getElementById(examYearPrevious).value == '') {
                alert(errorMsg);
                document.getElementById(examYearPrevious).focus();
            }
            else if (document.getElementById(subjectChosen).value == '') {
                alert(errorMsg);
                document.getElementById(subjectChosen).focus();
            }
            else if (document.getElementById(GradeObt).value == '') {
                alert(errorMsg);
                document.getElementById(GradeObt).focus();
            }
            else if (document.getElementById(BestGrade).value == '') {
                alert(errorMsg);
                document.getElementById(BestGrade).focus();
            }
            else if (document.getElementById(MarksObt).value == '' && document.getElementById(MaxMarks).value != '') {
                errorMsg = errorMsg;
                alert(errorMsg);
                document.getElementById(MarksObt).focus();
            }
            else if (document.getElementById(MaxMarks).value == '' && document.getElementById(MarksObt).value != '') {
                errorMsg = errorMsg + ' and maximum marks mandatory when marks mbtained is entered';
                alert(errorMsg);
                document.getElementById(MaxMarks).focus();
            }
            else if (document.getElementById(LevelChosen).selectedIndex == 0) {
                alert(errorMsg);
                document.getElementById(LevelChosen).focus();
            }
        }
    }
}

function Grade_Checking(type, selectedrow) {
    var examYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + selectedrow;
    var subjectChosen = '';
    if (type == 'HSPreNL' || type == 'NHSNL')
        subjectChosen = 'ctl00_CPH_EduQualification_' + type + 'SubTaken_TXT' + selectedrow;
    else
        subjectChosen = 'ctl00_CPH_EduQualification_' + type + 'SubTaken_DDL' + selectedrow;
    var GradeObt = 'ctl00_CPH_EduQualification_' + type + 'GradeObt_TXT' + selectedrow;
    var BestGrade = 'ctl00_CPH_EduQualification_' + type + 'BestGrade_TXT' + selectedrow;
    var LevelChosen = 'ctl00_CPH_EduQualification_' + type + 'Level_DDL' + selectedrow;

    if (document.getElementById(examYear).value == '') {
        alert('Please enter exam year before choosing the level');
        document.getElementById(LevelChosen).selectedIndex = 0;
        document.getElementById(examYear).focus();
    }
    else if (document.getElementById(subjectChosen).value == '') {
        if (type == 'HSPreNL' || type == 'NHSNL')
            alert('Please enter subject before choosing the level');
        else
            alert('Please choose subject before choosing the level');
        document.getElementById(LevelChosen).selectedIndex = 0;
        document.getElementById(subjectChosen).focus();
    }
    else if (document.getElementById(GradeObt).value == '' && document.getElementById(BestGrade).value == '') {
        alert('Please enter grade obtained and best grade');
        document.getElementById(LevelChosen).selectedIndex = 0;
        document.getElementById(GradeObt).focus();
    }
    else if (document.getElementById(GradeObt).value == '' && document.getElementById(BestGrade).value != '') {
        alert('Please enter grade obtained');
        document.getElementById(LevelChosen).selectedIndex = 0;
        document.getElementById(GradeObt).focus();
    }

    else {
        if (document.getElementById(BestGrade).value == '') {
            if (type == 'HSPreNL' || type == 'NHSNL')
                alert('Best grade mandatory when grade obtained is entered');
            else
                alert('Please enter best grade');
            document.getElementById(LevelChosen).selectedIndex = 0;
            document.getElementById(BestGrade).focus();
        }
        else {
            Marks_Checking(type, selectedrow);
            EducationRowExist(type, selectedrow);
        }
    }
}

function Marks_Checking(type, selectedrow) {
    var MarksObt = 'ctl00_CPH_EduQualification_' + type + 'MarksObt_TXT' + selectedrow;
    var MaxMarks = 'ctl00_CPH_EduQualification_' + type + 'MaxMarks_TXT' + selectedrow;
    var LevelChosen = 'ctl00_CPH_EduQualification_' + type + 'Level_DDL' + selectedrow;
    if (document.getElementById(MarksObt).value != '') {
        if (document.getElementById(MaxMarks).value == '') {
            alert('Maximum marks mandatory when marks obtained is entered');
            document.getElementById(LevelChosen).selectedIndex = 0;
            document.getElementById(MaxMarks).focus();
        }
        else {
            EducationRowExist(type, selectedrow);
        }
    }
}

function EducationRowExist(type, selectedrow) {
    var examYearCompare = new Array();
    var subjCompare = new Array();
    var LevelCompare = new Array();

    var examYeaFlag = false;
    var found = 1;
    var examYear = '';
    var subjectChosen = '';
    var LevelChosen = '';
    for (var i = 1; i <= selectedrow; i++) {
        examYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        if (type == 'HSPreNL' || type == 'NHSNL')
            subjectChosen = 'ctl00_CPH_EduQualification_' + type + 'SubTaken_TXT' + i;
        else
            subjectChosen = 'ctl00_CPH_EduQualification_' + type + 'SubTaken_DDL' + i;
        LevelChosen = 'ctl00_CPH_EduQualification_' + type + 'Level_DDL' + i;

        examYearCompare.push(document.getElementById(examYear).value);
        subjCompare.push(document.getElementById(subjectChosen).value);
        LevelCompare.push(document.getElementById(LevelChosen).value);
    }
    for (var i = 0; i < examYearCompare.length; i++) {
        for (var j = 0; j < examYearCompare.length; j++) {
            if (i != j) {
                if (examYearCompare[i] == examYearCompare[j])
                    if (subjCompare[i] == subjCompare[j])
                    if (LevelCompare[i] == LevelCompare[j]) {
                    found = 0;
                    break;
                }
            }
        }
        if (found == 0) {
            alert("All subjects and level chosen must be unique (no duplicaton).");
            document.getElementById(LevelChosen).selectedIndex = 0;
            break;
        }
    }
}

function Education_SubjectChange(type, selectedrow) {
    var examYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + selectedrow;
    var subjectChosen = '';
    if (type == 'HSPreNL' || type == 'NHSNL')
        subjectChosen = 'ctl00_CPH_EduQualification_' + type + 'SubTaken_TXT' + selectedrow;
    else
        subjectChosen = 'ctl00_CPH_EduQualification_' + type + 'SubTaken_DDL' + selectedrow;
    var GradeObt = 'ctl00_CPH_EduQualification_' + type + 'GradeObt_TXT' + selectedrow;
    var BestGrade = 'ctl00_CPH_EduQualification_' + type + 'BestGrade_TXT' + selectedrow;
    var LevelChosen = 'ctl00_CPH_EduQualification_' + type + 'Level_DDL' + selectedrow;

    if (document.getElementById(examYear).value == '') {
        alert('Please enter exam year before choosing the Subject');
        document.getElementById(subjectChosen).selectedIndex = 0;
        document.getElementById(examYear).focus();
    }
    else {
        EducationRowExist(type, selectedrow);
    }
}

function UKLevel_LeastSubjectCheck() {
    var HSexamYearCompare = new Array();
    var HSNLexamYearCompare = new Array();
    var found = 0;
    var examYear1 = '';
    var examYear2 = '';
    //var errorMsg='You must provide at least 3 subjects'; 
    var type = '';
    if (document.getElementById('ctl00_CPH_EduQualification_AcademicStatus_DDL').value == 1 && document.getElementById('ctl00_CPH_EduQualification_ResultsAvail_TXT').value == "") {
        alert("Please fill all the mandtory field in Educational Qualifications");
        document.getElementById('ctl00_CPH_EduQualification_PhySubHSchool_DDL').selectedIndex = 0;
        document.getElementById('ctl00_CPH_EduQualification_ResultsAvail_TXT').focus();
    }
    else {
        if (document.getElementById('ctl00_CPH_EduQualification_A2LevelMarks_PL').style.display != 'none' || document.getElementById('ctl00_CPH_EduQualification_ALevelMarks_PL').style.display != 'none') {
            if (document.getElementById('ctl00_CPH_EduQualification_AcademicStatus_DDL').value == 1 && document.getElementById('ctl00_CPH_EduQualification_FlagAcadStatusContent').value == 'P')
                type = 'HSPre';
            else if (document.getElementById('ctl00_CPH_EduQualification_AcademicStatus_DDL').value == 1 && document.getElementById('ctl00_CPH_EduQualification_FlagAcadStatusContent').value == 'A')
                type = 'NHS';
            else
                type = 'NHS';

            for (var i = 1; i <= 25; i++) {
                examYear1 = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
                if (document.getElementById(examYear1).value == '')
                    break;
                else
                    HSexamYearCompare.push(document.getElementById(examYear1).value);
            }

            if (document.getElementById('ctl00_CPH_EduQualification_AcademicStatus_DDL').value == 1 && document.getElementById('ctl00_CPH_EduQualification_FlagAcadStatusContent').value == 'P')
                type = 'HSPreNL';
            else if (document.getElementById('ctl00_CPH_EduQualification_AcademicStatus_DDL').value == 1 && document.getElementById('ctl00_CPH_EduQualification_FlagAcadStatusContent').value == 'A')
                type = 'NHSNL';
            else
                type = 'NHSNL';

            for (var i = 1; i <= 15; i++) {
                examYear2 = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
                if (document.getElementById(examYear2).value == '')
                    break;
                else
                    HSNLexamYearCompare.push(document.getElementById(examYear2).value);
            }

            if (HSexamYearCompare.length >= 3 && HSNLexamYearCompare.length <= 0)
                found = 0;
            else if (HSexamYearCompare.length >= 1 && HSNLexamYearCompare.length >= 2)
                found = 0;
            else if (HSexamYearCompare.length >= 2 && HSNLexamYearCompare.length >= 1)
                found = 0;
            else
                found = 1;

            if (found == 1) {
                alert("You must provide at least 3 subjects");
                document.getElementById('ctl00_CPH_EduQualification_PhySubHSchool_DDL').selectedIndex = 0;
                // document.getElementById('ctl00_CPH_EduQualification_PhySubHSchool_DDL').focus(); 
            }
        }
    }

}
/*UKLevel'A' Validation End*/

/*USHS validation Start*/

function isValidYear(strYear) {
    if (strYear.length == 9) {
        if (strYear.indexOf("/") != 4) {
            return false;
        }
        var Year1 = strYear.substring(0, 4);
        var Year2 = strYear.substring(5, 9);
        var d1 = new Date(Year1, 1, 0);

        var d2 = new Date(Year2, 1, 0);
        if (d1.getFullYear() == Year1 && d2.getFullYear() == Year2 && Year1 < Year2) {
            return true;
        }
    }
    return false;
}

function USHS_GradeCheck(type, selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var GradeChosen = 'ctl00_CPH_EduQualification_' + type + 'Grade_DDL' + i;
        var examYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        if (document.getElementById(GradeChosen).value == '') {
            alert('Please select grade');
            document.getElementById(GradeChosen).selectedIndex = 0;
            document.getElementById(examYear).value = '';
            document.getElementById(GradeChosen).focus();
            break;
        }
        else
            continue;

    }
}


function USHS_SemesterChange(type, selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var GradeChosen = 'ctl00_CPH_EduQualification_' + type + 'Grade_DDL' + i;
        var examYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        var SemesterChosen = 'ctl00_CPH_EduQualification_' + type + 'Semester_DDL' + i;
        var errorMsg = 'Columns with * are mandatory once grade is selected';
        if (document.getElementById(GradeChosen).value == '') {
            alert('Please select grade');
            document.getElementById(GradeChosen).selectedIndex = 0;
            document.getElementById(SemesterChosen).selectedIndex = 0;
            document.getElementById(GradeChosen).focus();
            break;
        }
        else if (document.getElementById(examYear).value == '') {
            alert(errorMsg);
            document.getElementById(SemesterChosen).selectedIndex = 0;
            document.getElementById(examYear).focus();
            break;
        }
        else if (document.getElementById(examYear).value != '' && !isValidYear(document.getElementById(examYear).value)) {
            document.getElementById(examYear).value = '';
            alert('Please provide correct exam year in YYYY/YYYY format');
            document.getElementById(SemesterChosen).selectedIndex = 0;
            document.getElementById(examYear).focus();
            break;
        }
        else
            continue;
    }
}

function USHS_SubjectChange(type, selectedrow) {
    var SubjectChosen;
    for (var i = 1; i <= selectedrow; i++) {
        var GradeChosen = 'ctl00_CPH_EduQualification_' + type + 'Grade_DDL' + i;
        var examYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        var SemesterChosen = 'ctl00_CPH_EduQualification_' + type + 'Semester_DDL' + i;
        if (type == 'USHSPreNL')
            SubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_TXT' + i;
        else
            SubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_DDL' + i;
        var errorMsg = 'Columns with * are mandatory once grade is selected';
        if (document.getElementById(GradeChosen).value == '') {
            alert('Please select grade');
            document.getElementById(GradeChosen).selectedIndex = 0;
            document.getElementById(SubjectChosen).value = '';
            if (type == 'USHSPre') {
                document.getElementById(SubjectChosen).selectedIndex = 0;
            }
            document.getElementById(GradeChosen).focus();
            break;
        }
        else if (document.getElementById(examYear).value == '') {
            alert(errorMsg);
            document.getElementById(SubjectChosen).value = '';
            if (type == 'USHSPre')
                document.getElementById(SubjectChosen).selectedIndex = 0;
            document.getElementById(examYear).focus();
            break;
        }
        else
            USHS_CheckUniqueEntry(type, selectedrow);
    }
}



//todo
function USHS_CheckUniqueEntry(type, selectedrow) {
    var GradeCompare = new Array();
    var ExamYearCompare = new Array();
    var SemesterCompare = new Array();
    var SubjectCompare = new Array();
    var found = 1;
    for (var i = 1; i <= selectedrow; i++) {
        var grade = '';
        var examYear = '';
        var semesterChosen = '';
        var subjectChosen = '';
        grade = 'ctl00_CPH_EduQualification_' + type + 'Grade_DDL' + i;
        examYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        semesterChosen = 'ctl00_CPH_EduQualification_' + type + 'Semester_DDL' + i;
        if (type == 'USHSPreNL') {
            subjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_TXT' + i;
        }
        else {
            subjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_DDL' + i;
        }
        GradeCompare.push(document.getElementById(grade).value);
        ExamYearCompare.push(document.getElementById(examYear).value);
        SemesterCompare.push(document.getElementById(semesterChosen).value);
        SubjectCompare.push(document.getElementById(subjectChosen).value);
    }

    for (var i = 0; i < GradeCompare.length; i++) {
        for (var j = 0; j < GradeCompare.length; j++) {
            if (i != j) {
                if (GradeCompare[i] == GradeCompare[j])
                    if (ExamYearCompare[i] == ExamYearCompare[j])
                    if (SemesterCompare[i] == SemesterCompare[j])
                    if (SubjectCompare[i] == SubjectCompare[j]) {
                    found = 0;
                    break;
                }
                else
                    continue;
            }
        }
        if (found == 0) {
            alert("Subject chosen in same grade & semester must be unique.");
            document.getElementById(subjectChosen).value = '';
            if (type == 'USHSPre')
                document.getElementById(subjectChosen).selectedIndex = 0;
            document.getElementById(subjectChosen).selectedIndex = 0;
            document.getElementById(subjectChosen).focus();
            break;

        }
    }
}

function USHS_GradeObtCheck(type, selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var GradeChosen = 'ctl00_CPH_EduQualification_' + type + 'Grade_DDL' + i;
        var examYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        var SemesterChosen = 'ctl00_CPH_EduQualification_' + type + 'Semester_DDL' + i;
        var SubjectChosen = '';
        if (type == 'USHSPreNL')
            SubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_TXT' + i;
        else
            SubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_DDL' + i;
        var GradeObt = 'ctl00_CPH_EduQualification_' + type + 'GradeObt_TXT' + i;
        var errorMsg = 'Columns with * are mandatory once grade is selected';
        if (document.getElementById(GradeChosen).value == '') {
            alert('Please select grade');
            document.getElementById(GradeChosen).selectedIndex = 0;
            if (type == 'USHSPre')
                document.getElementById(SubjectChosen).selectedIndex = 0;
            document.getElementById(GradeChosen).focus();
            break;
        }
        else if (document.getElementById(examYear).value == '') {
            alert(errorMsg);
            document.getElementById(examYear).focus();
            break;
        }
        else if (document.getElementById(SubjectChosen).value == '') {
            alert(errorMsg);
            document.getElementById(SubjectChosen).selectedIndex = 0;
            document.getElementById(GradeObt).value = '';
            document.getElementById(SubjectChosen).focus();
            break;
        }
        else
            continue;
    }
}

function USHS_MaxMarksCheck(type, selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var GradeChosen = 'ctl00_CPH_EduQualification_' + type + 'Grade_DDL' + i;
        var examYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        var SemesterChosen = 'ctl00_CPH_EduQualification_' + type + 'Semester_DDL' + i;
        var SubjectChosen = '';
        if (type == 'USHSPreNL')
            SubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_TXT' + i;
        else
            SubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_DDL' + i;
        var GradeObt = 'ctl00_CPH_EduQualification_' + type + 'GradeObt_TXT' + i;
        var MaxMarks = 'ctl00_CPH_EduQualification_' + type + 'MaxMarks_TXT' + i;
        var errorMsg = 'Columns with * are mandatory once grade is selected';
        if (document.getElementById(GradeChosen).value == '') {
            alert('Please select grade');
            document.getElementById(GradeChosen).selectedIndex = 0;
            if (type == 'USHSPre')
                document.getElementById(SubjectChosen).selectedIndex = 0;
            document.getElementById(GradeChosen).focus();
            break;
        }
        else if (document.getElementById(examYear).value == '') {
            alert(errorMsg);
            document.getElementById(examYear).focus();
            break;
        }
        else if (document.getElementById(SubjectChosen).value == '') {
            alert(errorMsg);
            if (type == 'USHSPre')
                document.getElementById(SubjectChosen).selectedIndex = 0;
            document.getElementById(GradeObt).value = '';
            document.getElementById(SubjectChosen).focus();
            break;
        }
        else if (document.getElementById(GradeObt).value == '') {
            alert(errorMsg);
            document.getElementById(MaxMarks).value = '';
            document.getElementById(GradeObt).focus();
            break;
        }
        else
            continue;
    }
}


function USHS_LevelChange(type, selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var GradeChosen = 'ctl00_CPH_EduQualification_' + type + 'Grade_DDL' + i;
        var examYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        var SemesterChosen = 'ctl00_CPH_EduQualification_' + type + 'Semester_DDL' + i;
        var SubjectChosen = '';
        if (type == 'USHSPreNL')
            SubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_TXT' + i;
        else
            SubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_DDL' + i;
        var GradeObt = 'ctl00_CPH_EduQualification_' + type + 'GradeObt_TXT' + i;
        var MaxMarks = 'ctl00_CPH_EduQualification_' + type + 'MaxMarks_TXT' + i;
        var LevelChosen = 'ctl00_CPH_EduQualification_' + type + 'Level_DDL' + i;
        var errorMsg = 'Columns with * are mandatory once grade is selected';
        if (document.getElementById(GradeChosen).value == '') {
            alert('Please select grade');
            document.getElementById(GradeChosen).selectedIndex = 0;
            if (type == 'USHSPre')
                document.getElementById(SubjectChosen).selectedIndex = 0;
            document.getElementById(LevelChosen).selectedIndex = 0;
            document.getElementById(GradeChosen).focus();
            break;
        }
        else if (document.getElementById(examYear).value == '') {
            alert(errorMsg);
            document.getElementById(LevelChosen).selectedIndex = 0;
            document.getElementById(examYear).focus();
            break;
        }
        else if (document.getElementById(SubjectChosen).value == '') {
            alert(errorMsg);
            if (type == 'USHSPre')
                document.getElementById(SubjectChosen).selectedIndex = 0;
            document.getElementById(LevelChosen).selectedIndex = 0;
            document.getElementById(GradeObt).value = '';
            document.getElementById(SubjectChosen).focus();
            break;
        }
        else if (document.getElementById(GradeObt).value == '') {
            alert(errorMsg);
            document.getElementById(MaxMarks).value = '';
            document.getElementById(LevelChosen).selectedIndex = 0;
            document.getElementById(GradeObt).focus();
            break;
        }
        else if (document.getElementById(MaxMarks).value == '') {
            alert(errorMsg);
            document.getElementById(LevelChosen).selectedIndex = 0;
            document.getElementById(MaxMarks).focus();
            break;
        }
        else
            continue;
    }
}

function USHS_Row_Validate(type, selectedrow) {
    var SelectedGradeChosen = 'ctl00_CPH_EduQualification_' + type + 'Grade_DDL' + selectedrow;
    var SelectedExamYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + selectedrow;
    var SelectedSemesterChosen = 'ctl00_CPH_EduQualification_' + type + 'Semester_DDL' + selectedrow;
    var SelectedSubjectChosen = '';
    if (type == 'USHSPreNL')
        SelectedSubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_TXT' + selectedrow;
    else
        SelectedSubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_DDL' + selectedrow;
    var SelectedGradeObt = 'ctl00_CPH_EduQualification_' + type + 'GradeObt_TXT' + selectedrow;
    var SelectedMaxMarks = 'ctl00_CPH_EduQualification_' + type + 'MaxMarks_TXT' + selectedrow;
    var SelectedLevelChosen = 'ctl00_CPH_EduQualification_' + type + 'Level_DDL' + selectedrow;
    var errorMsg = 'Please fill the previous row';
    for (var i = 1; i < selectedrow; i++) {
        var PreviousGradeChosen = 'ctl00_CPH_EduQualification_' + type + 'Grade_DDL' + i;
        var PreviousExamYear = 'ctl00_CPH_EduQualification_' + type + 'ExYear_TXT' + i;
        var PreviousSemesterChosen = 'ctl00_CPH_EduQualification_' + type + 'Semester_DDL' + i;
        var PreviousSubjectChosen = '';
        if (type == 'USHSPreNL')
            PreviousSubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_TXT' + i;
        else
            PreviousSubjectChosen = 'ctl00_CPH_EduQualification_' + type + 'Subject_DDL' + i;
        var PreviousGradeObt = 'ctl00_CPH_EduQualification_' + type + 'GradeObt_TXT' + i;
        var PreviousMaxMarks = 'ctl00_CPH_EduQualification_' + type + 'MaxMarks_TXT' + i;
        var PreviousLevelChosen = 'ctl00_CPH_EduQualification_' + type + 'Level_DDL' + i;

        if (document.getElementById(PreviousGradeChosen).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedGradeChosen).value = '';
            document.getElementById(SelectedGradeChosen).selectedIndex = 0;
            document.getElementById(SelectedSemesterChosen).value = '';
            document.getElementById(SelectedSemesterChosen).selectedIndex = 0;
            document.getElementById(SelectedSubjectChosen).value = '';
            if (type == 'USHSPre')
                document.getElementById(SelectedSubjectChosen).selectedIndex = 0;
            document.getElementById(SelectedLevelChosen).value = '';
            document.getElementById(SelectedLevelChosen).selectedIndex = 0;
            document.getElementById(PreviousGradeChosen).focus();
            break;
        }
        else if (document.getElementById(PreviousExamYear).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedExamYear).value = '';
            document.getElementById(SelectedGradeChosen).value = '';
            document.getElementById(SelectedGradeChosen).selectedIndex = 0;
            document.getElementById(SelectedSemesterChosen).value = '';
            document.getElementById(SelectedSemesterChosen).selectedIndex = 0;
            document.getElementById(SelectedSubjectChosen).value = '';
            if (type == 'USHSPre')
                document.getElementById(SelectedSubjectChosen).selectedIndex = 0;
            document.getElementById(SelectedLevelChosen).value = '';
            document.getElementById(SelectedLevelChosen).selectedIndex = 0;
            document.getElementById(PreviousExamYear).focus();
            break;
        }
        else if (document.getElementById(PreviousSubjectChosen).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedGradeChosen).value = '';
            document.getElementById(SelectedGradeChosen).selectedIndex = 0;
            document.getElementById(SelectedSemesterChosen).value = '';
            document.getElementById(SelectedSemesterChosen).selectedIndex = 0;
            document.getElementById(SelectedSubjectChosen).value = '';
            if (type == 'USHSPre')
                document.getElementById(SelectedSubjectChosen).selectedIndex = 0;
            document.getElementById(SelectedLevelChosen).value = '';
            document.getElementById(SelectedLevelChosen).selectedIndex = 0;
            document.getElementById(PreviousSubjectChosen).focus();
            break;
        }
        else if (document.getElementById(PreviousGradeObt).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedGradeObt).value = '';
            document.getElementById(SelectedGradeChosen).value = '';
            document.getElementById(SelectedGradeChosen).selectedIndex = 0;
            document.getElementById(SelectedSemesterChosen).value = '';
            document.getElementById(SelectedSemesterChosen).selectedIndex = 0;
            document.getElementById(SelectedSubjectChosen).value = '';
            if (type == 'USHSPre')
                document.getElementById(SelectedSubjectChosen).selectedIndex = 0;
            document.getElementById(SelectedLevelChosen).value = '';
            document.getElementById(SelectedLevelChosen).selectedIndex = 0;
            document.getElementById(PreviousGradeObt).focus();
            break;
        }
        else if (document.getElementById(PreviousMaxMarks).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedMaxMarks).value = '';
            document.getElementById(SelectedGradeChosen).value = '';
            document.getElementById(SelectedGradeChosen).selectedIndex = 0;
            document.getElementById(SelectedSemesterChosen).value = '';
            document.getElementById(SelectedSemesterChosen).selectedIndex = 0;
            document.getElementById(SelectedSubjectChosen).value = '';
            if (type == 'USHSPre')
                document.getElementById(SelectedSubjectChosen).selectedIndex = 0;
            document.getElementById(SelectedLevelChosen).value = '';
            document.getElementById(SelectedLevelChosen).selectedIndex = 0;
            document.getElementById(PreviousMaxMarks).focus();
            break;
        }
        else
            continue;
    }
}

function USHS_LeastRowCheck() {
    var GradeChosen = 'ctl00_CPH_EduQualification_USHSPreGrade_DDL1';
    var examYear = 'ctl00_CPH_EduQualification_USHSPreExYear_TXT1';
    var SemesterChosen = 'ctl00_CPH_EduQualification_USHSPreSemester_DDL1';
    var SubjectChosen = 'ctl00_CPH_EduQualification_USHSPreSubject_DDL1';
    var GradeObt = 'ctl00_CPH_EduQualification_USHSPreGradeObt_TXT1';
    var MaxMarks = 'ctl00_CPH_EduQualification_USHSPreMaxMarks_TXT1';
    var LevelChosen = 'ctl00_CPH_EduQualification_USHSPreLevel_DDL1';
    var PhySubHSchoolChange = 'ctl00_CPH_EduQualification_PhySubHSchool_DDL';
    var errorMsg = 'Columns with * are mandatory once grade is selected in Grade 11 & 12 Examination results ';
    if (document.getElementById(GradeChosen).value == '' &&
       document.getElementById(examYear).value == '' &&
       document.getElementById(SemesterChosen).value == '' &&
       document.getElementById(SubjectChosen).value == '' &&
       document.getElementById(GradeObt).value == '' &&
       document.getElementById(MaxMarks).value == '') {
        alert('You must provide at least 5 subjects each of Grade_Checking 11&12');
        document.getElementById(GradeChosen).value = '';
        document.getElementById('ctl00_CPH_EduQualification_USHSPreNLGrade_DDL1').value = '';
        document.getElementById('ctl00_CPH_EduQualification_USHSPreNLGrade_DDL1').selectedIndex = 0;
        document.getElementById(PhySubHSchoolChange).selectedIndex = 0;
        document.getElementById(GradeChosen).focus();
    }
    else {
        if (document.getElementById(GradeChosen).value == '') {
            alert('Please select grade');
            document.getElementById(examYear).value = '';
            document.getElementById(GradeChosen).focus();
        }
        else if (document.getElementById(examYear).value == '') {
            alert(errorMsg);
            document.getElementById(SemesterChosen).selectedIndex = 0;
            document.getElementById(examYear).focus();
        }
        else if (document.getElementById(SubjectChosen).value == '') {
            alert(errorMsg);
            document.getElementById(GradeObt).value = '';
            document.getElementById(SubjectChosen).focus();
        }
        else if (document.getElementById(GradeObt).value == '') {
            alert(errorMsg);
            document.getElementById(MaxMarks).value = '';
            document.getElementById(GradeObt).focus();
        }
        else if (document.getElementById(MaxMarks).value == '') {
            alert(errorMsg);
            document.getElementById(LevelChosen).value = '';
            document.getElementById(LevelChosen).selectedIndex = 0;
            document.getElementById(MaxMarks).focus();
        }
    }
}
function imposeMaxLength(Event, Object, MaxLen) {
    return (Object.value.length <= MaxLen) || (Event.keyCode == 8 || Event.keyCode == 46 || (Event.keyCode >= 35 && Event.keyCode <= 40))
}
function CheckResultsFocus() {
    document.getElementById('ctl00_CPH_EduQualification_ResultsAvail_TXT').focus();
}

function CheckResultsAvail() {
    var acadstatus = document.getElementById('ctl00_CPH_EduQualification_AcademicStatus_DDL').value;
    if (acadstatus != "" && acadstatus == 1) {

        var strDate = document.getElementById('ctl00_CPH_EduQualification_ResultsAvail_TXT').value;
        var flag = 0;
        if (strDate != '') {
            var arrDate = strDate.split('-');
            if (arrDate.length == 2) {
                var resultDate = new Date(arrDate[1], arr[arrDate[0].toUpperCase()]);
                var x = new Date();
                var month = new Array(12);
                month[0] = "JAN";
                month[1] = "FEB";
                month[2] = "MAR";
                month[3] = "APR";
                month[4] = "MAY";
                month[5] = "JUN";
                month[6] = "JUL";
                month[7] = "AUG";
                month[8] = "SEP";
                month[9] = "OCT";
                month[10] = "NOV";
                month[11] = "DEC";
                var monthString = new Array(12);
                monthString["JAN"] = 0;
                monthString["FEB"] = 1;
                monthString["MAR"] = 2;
                monthString["APR"] = 3;
                monthString["MAY"] = 4;
                monthString["JUN"] = 5;
                monthString["JUL"] = 6;
                monthString["AUG"] = 7;
                monthString["SEP"] = 8;
                monthString["OCT"] = 9;
                monthString["NOV"] = 10;
                monthString["DEC"] = 11;
                if (arrDate[1] == x.getFullYear()) {
                    if (monthString[arrDate[0].toUpperCase()] <= x.getMonth())
                        flag = 2;
                    else
                        flag = 1;
                }
                else if (arrDate[1] > x.getFullYear()) {
                    flag = 1;
                }
                else if (arrDate[1] < x.getFullYear()) {
                    flag = 2;
                }
                else {
                    flag = 2;
                }
                if (flag == 1) { //predicted 
                    document.getElementById('ctl00_CPH_EduQualification_A2LevelMarks_PL').style.display = 'none';
                    document.getElementById('ctl00_CPH_EduQualification_ALevelMarks_PL').style.display = 'block';
                    document.getElementById('ctl00_CPH_EduQualification_ALevelresults_PL').style.display = 'block';
                }
                else if (flag == 2) { //actuall
                    document.getElementById('ctl00_CPH_EduQualification_ALevelMarks_PL').style.display = 'none';
                    document.getElementById('ctl00_CPH_EduQualification_ALevelresults_PL').style.display = 'none';
                    document.getElementById('ctl00_CPH_EduQualification_A2LevelMarks_PL').style.display = 'block';
                }
                else {
                    document.getElementById('ctl00_CPH_EduQualification_A2LevelMarks_PL').style.display = 'none';
                    document.getElementById('ctl00_CPH_EduQualification_ALevelMarks_PL').style.display = 'none';
                    document.getElementById('ctl00_CPH_EduQualification_ALevelresults_PL').style.display = 'none';
                }
            }
        }
        else {
            document.getElementById('ctl00_CPH_EduQualification_A2LevelMarks_PL').style.display = 'none';
            document.getElementById('ctl00_CPH_EduQualification_ALevelMarks_PL').style.display = 'none';
            document.getElementById('ctl00_CPH_EduQualification_ALevelresults_PL').style.display = 'none';
        }
    }
}
function sortNumber(a, b) {
    return a - b;
}



function USHS_LeastSubjectCheck() {
    var USHSGradeCompare = new Array();
    var USHSNLGradeCompare = new Array();
    var found = 0;
    var GradeCount11 = 0;
    var GradeCount12 = 0;
    var ushsgrade = '';
    var ushsnlgrade = '';
    var errorMsg = 'You must provide at least 5 subjects each of Grade_Checking 11&12';
    for (var i = 1; i <= 25; i++) {
        ushsgrade = 'ctl00_CPH_EduQualification_USHSPreGrade_DDL' + i;
        if (document.getElementById(ushsgrade).value == '')
            break;
        else
            USHSGradeCompare.push(document.getElementById(ushsgrade).value);
    }
    for (var i = 1; i <= 15; i++) {
        ushsnlgrade = 'ctl00_CPH_EduQualification_USHSPreNLGrade_DDL' + i;
        if (document.getElementById(ushsnlgrade).value == '')
            break;
        else
            USHSNLGradeCompare.push(document.getElementById(ushsnlgrade).value);
    }
    USHSGradeCompare.sort(sortNumber);
    USHSNLGradeCompare.sort(sortNumber);
    for (var i = 0; i < USHSGradeCompare.length; i++) {
        if (USHSGradeCompare[i] == '11')
            GradeCount11++;
        else
            GradeCount12++;
    }
    for (var i = 0; i < USHSNLGradeCompare.length; i++) {
        if (USHSNLGradeCompare[i] == '11')
            GradeCount11++;
        else
            GradeCount12++;
    }
    if (GradeCount11 < 5 || GradeCount12 < 5) {
        document.getElementById('ctl00_CPH_EduQualification_PhySubHSchool_DDL').selectedIndex = 0;
        alert(errorMsg);
        return false;
    }
}

/*USHS validation Start*/
function chkAgreeDeclaration() {
    var chkAgree = 'ctl00_CPH_Declaration_chkAgreeDeclaration';
    if (!document.getElementById(chkAgree).checked) {
        alert('Please check declarations before enter password');
        document.getElementById('ctl00_CPH_Declaration_Password_TXT').value = '';
        document.getElementById(chkAgree).focus();
    }
}

/*NAA - Validation Start*/
function NAA_LevelCheck(selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var ActivityLevel = 'ctl00_CPH_Achievement_ActivityLevel_DDL' + i;
        if (document.getElementById(ActivityLevel).value == '') {
            alert('Please indicate level of participation');
            document.getElementById(ActivityLevel).selectedIndex = 0;
            document.getElementById(ActivityLevel).focus();
            break;
        }
        else
            continue;

    }
}
function NAA_CategoryCheck(selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var ActivityLevel = 'ctl00_CPH_Achievement_ActivityLevel_DDL' + i;
        var ActivityCategory = 'ctl00_CPH_Achievement_ActivityCategory_DDL' + i;
        if (document.getElementById(ActivityLevel).value == '') {
            alert('Please indicate level of participation');
            document.getElementById(ActivityLevel).selectedIndex = 0;
            document.getElementById(ActivityLevel).focus();
            break;
        }
        else if (document.getElementById(ActivityCategory).value == '') {
            alert('Please indicate Category of participation');
            document.getElementById(ActivityCategory).selectedIndex = 0;
            document.getElementById(ActivityCategory).focus();
            break;
        }
        else
            continue;
    }
}
function NAA_NameCheck(selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var ActivityLevel = 'ctl00_CPH_Achievement_ActivityLevel_DDL' + i;
        var ActivityCategory = 'ctl00_CPH_Achievement_ActivityCategory_DDL' + i;
        var ActivityName = 'ctl00_CPH_Achievement_ActivityName_TXT' + i;
        if (document.getElementById(ActivityLevel).value == '') {
            alert('Please indicate level of participation');
            document.getElementById(ActivityLevel).selectedIndex = 0;
            document.getElementById(ActivityLevel).focus();
            break;
        }
        else if (document.getElementById(ActivityCategory).value == '') {
            alert('Please indicate Category of participation');
            document.getElementById(ActivityCategory).selectedIndex = 0;
            document.getElementById(ActivityCategory).focus();
            break;
        }
        else if (document.getElementById(ActivityName).value == '') {
            alert('Please indicate name of activity/event/competition');
            document.getElementById(ActivityName).focus();
            break;
        }
        else
            continue;
    }
}
function NAA_PostionHeldCheck(selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var ActivityLevel = 'ctl00_CPH_Achievement_ActivityLevel_DDL' + i;
        var ActivityCategory = 'ctl00_CPH_Achievement_ActivityCategory_DDL' + i;
        var ActivityName = 'ctl00_CPH_Achievement_ActivityName_TXT' + i;
        var positionHeld = 'ctl00_CPH_Achievement_PositionHeld_TXT' + i;
        if (document.getElementById(ActivityLevel).value == '') {
            alert('Please indicate level of participation');
            document.getElementById(ActivityLevel).selectedIndex = 0;
            document.getElementById(ActivityLevel).focus();
            break;
        }
        else if (document.getElementById(ActivityCategory).value == '') {
            alert('Please indicate category of participation');
            document.getElementById(ActivityCategory).selectedIndex = 0;
            document.getElementById(ActivityCategory).focus();
            break;
        }
        else if (document.getElementById(ActivityName).value == '') {
            alert('Please indicate name of activity/event/competition');
            document.getElementById(ActivityName).focus();
            break;
        }
        else if (document.getElementById(positionHeld).value == '') {
            alert('Please indicate position held');
            document.getElementById(positionHeld).focus();
            break;
        }
        else
            continue;
    }
}
function NAA_StartDateCheck(selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var ActivityLevel = 'ctl00_CPH_Achievement_ActivityLevel_DDL' + i;
        var ActivityCategory = 'ctl00_CPH_Achievement_ActivityCategory_DDL' + i;
        var ActivityName = 'ctl00_CPH_Achievement_ActivityName_TXT' + i;
        var positionHeld = 'ctl00_CPH_Achievement_PositionHeld_TXT' + i;
        var ActivityFromDate = 'ctl00_CPH_Achievement_ActivityFromDate_TXT' + i;
        if (document.getElementById(ActivityLevel).value == '') {
            alert('Please indicate level of participation');
            document.getElementById(ActivityLevel).selectedIndex = 0;
            document.getElementById(ActivityLevel).focus();
            break;
        }
        else if (document.getElementById(ActivityCategory).value == '') {
            alert('Please indicate Category of participation');
            document.getElementById(ActivityCategory).selectedIndex = 0;
            document.getElementById(ActivityCategory).focus();
            break;
        }
        else if (document.getElementById(ActivityName).value == '') {
            alert('Please indicate name of activity/event/competition');
            document.getElementById(ActivityName).focus();
            break;
        }
        else if (document.getElementById(positionHeld).value == '') {
            alert('Please indicate position held');
            document.getElementById(positionHeld).focus();
            break;
        }
        else if (document.getElementById(ActivityFromDate).value == '') {
            alert('Please provide the start date in ‘From’ column in MMM-YYYY format');
            document.getElementById(ActivityFromDate).focus();
            break;
        }
        else if (document.getElementById(ActivityFromDate).value != '' && !isValidDate(document.getElementById(ActivityFromDate).value)) {
            document.getElementById(ActivityFromDate).value = '';
            alert('Please provide the start date in ‘From’ column in MMM-YYYY format');
            document.getElementById(ActivityFromDate).focus();
            break;
        }
        else
            continue;
    }
}
function NAA_EndDateCheck(selectedrow) {
    for (var i = 1; i <= selectedrow; i++) {
        var ActivityLevel = 'ctl00_CPH_Achievement_ActivityLevel_DDL' + i;
        var ActivityCategory = 'ctl00_CPH_Achievement_ActivityCategory_DDL' + i;
        var ActivityName = 'ctl00_CPH_Achievement_ActivityName_TXT' + i;
        var positionHeld = 'ctl00_CPH_Achievement_PositionHeld_TXT' + i;
        var ActivityToDate = 'ctl00_CPH_Achievement_ActivityToDate_TXT' + i;
        var ActivityFromDate = 'ctl00_CPH_Achievement_ActivityFromDate_TXT' + i;
        if (document.getElementById(ActivityLevel).value == '') {
            alert('Please indicate level of participation');
            document.getElementById(ActivityLevel).selectedIndex = 0;
            document.getElementById(ActivityLevel).focus();
            break;
        }
        else if (document.getElementById(ActivityCategory).value == '') {
            alert('Please indicate Category of participation');
            document.getElementById(ActivityCategory).selectedIndex = 0;
            document.getElementById(ActivityCategory).focus();
            break;
        }
        else if (document.getElementById(ActivityName).value == '') {
            alert('Please indicate name of activity/event/competition');
            document.getElementById(ActivityName).focus();
            break;
        }
        else if (document.getElementById(positionHeld).value == '') {
            alert('Please indicate position held');
            document.getElementById(positionHeld).focus();
            break;
        }
        else if (document.getElementById(ActivityFromDate).value == '') {
            alert('Please provide the start date in ‘From’ column in MMM-YYYY format');
            document.getElementById(ActivityFromDate).focus();
            break;
        }
        else if (document.getElementById(ActivityFromDate).value != '' && !isValidDate(document.getElementById(ActivityFromDate).value)) {
            document.getElementById(ActivityFromDate).value = '';
            alert('Please provide the start date in ‘From’ column in MMM-YYYY format');
            document.getElementById(ActivityFromDate).focus();
            break;
        }
        else if (document.getElementById(ActivityToDate).value == '') {
            alert('Please provide the end date in ‘To’ column in MMM-YYYY format');
            document.getElementById(ActivityToDate).focus();
            break;
        }
        else if (document.getElementById(ActivityToDate).value != '' && !isValidDate(document.getElementById(ActivityToDate).value)) {
            document.getElementById(ActivityToDate).value = '';
            alert('Please provide the end date in ‘To’ column in MMM-YYYY format');
            document.getElementById(ActivityToDate).focus();
            break;
        }
        else
            continue;
    }
}

function NAA_Row_Validate(selectedrow) {
    var SelectedActivityLevel = 'ctl00_CPH_Achievement_ActivityLevel_DDL' + selectedrow;
    var SelectedActivityCategory = 'ctl00_CPH_Achievement_ActivityCategory_DDL' + selectedrow;
    var SelectedActivityName = 'ctl00_CPH_Achievement_ActivityName_TXT' + selectedrow;
    var SelectedPositionHeld = 'ctl00_CPH_Achievement_PositionHeld_TXT' + selectedrow;
    var SelectedActivityFromDate = 'ctl00_CPH_Achievement_ActivityFromDate_TXT' + selectedrow;
    var SelectedActivityToDate = 'ctl00_CPH_Achievement_ActivityToDate_TXT' + selectedrow;
    var errorMsg = "Please fill the previous row";
    for (var i = 1; i < selectedrow; i++) {
        var PreviousActivityLevel = 'ctl00_CPH_Achievement_ActivityLevel_DDL' + i;
        var PreviousActivityCategory = 'ctl00_CPH_Achievement_ActivityCategory_DDL' + i;
        var PreviousActivityName = 'ctl00_CPH_Achievement_ActivityName_TXT' + i;
        var PreviousPositionHeld = 'ctl00_CPH_Achievement_PositionHeld_TXT' + i;
        var PreviousActivityFromDate = 'ctl00_CPH_Achievement_ActivityFromDate_TXT' + i;
        var PreviousActivityToDate = 'ctl00_CPH_Achievement_ActivityToDate_TXT' + i;
        var PreviousActivityDesc = 'ctl00_CPH_Achievement_ListOFAward_TXT' + i;
        if (document.getElementById(PreviousActivityLevel).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedActivityLevel).value = '';
            document.getElementById(SelectedActivityLevel).selectedIndex = 0;
            document.getElementById(PreviousActivityLevel).focus();
            break;
        }
        else if (document.getElementById(PreviousActivityCategory).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedActivityCategory).value = '';
            document.getElementById(SelectedActivityCategory).selectedIndex = 0;
            document.getElementById(PreviousActivityCategory).focus();
            break;
        }
        else if (document.getElementById(PreviousActivityName).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedActivityName).value = '';
            document.getElementById(PreviousActivityName).focus();
            break;
        }
        else if (document.getElementById(PreviousPositionHeld).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedPositionHeld).value = '';
            document.getElementById(PreviousPositionHeld).focus();
            break;
        }
        else if (document.getElementById(PreviousActivityFromDate).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedActivityFromDate).value = '';
            document.getElementById(PreviousActivityFromDate).focus();
            break;
        }
        else if (document.getElementById(PreviousActivityFromDate).value != '' && !isValidDate(document.getElementById(PreviousActivityFromDate).value)) {
            document.getElementById(PreviousActivityFromDate).value = '';
            alert('Please provide the start date in ‘From’ column in MMM-YYYY format');
            document.getElementById(PreviousActivityFromDate).focus();
        }
        else if (document.getElementById(PreviousActivityToDate).value == '') {
            alert(errorMsg);
            document.getElementById(SelectedActivityToDate).value = '';
            document.getElementById(PreviousActivityToDate).focus();
            break;
        }
        else if (document.getElementById(PreviousActivityToDate).value != '' && !isValidDate(document.getElementById(PreviousActivityToDate).value)) {
            document.getElementById(PreviousActivityToDate).value = '';
            alert('Please provide the end date in ‘To’ column in MMM-YYYY format');
            document.getElementById(PreviousActivityToDate).focus();
            break
        }
        else if (document.getElementById(PreviousActivityDesc).value == '') {
            alert('Please list awards/certificates received or elaborate your involvements');
            document.getElementById(SelectedActivityLevel).value = '';
            document.getElementById(SelectedActivityLevel).selectedIndex = 0;
            document.getElementById(PreviousActivityDesc).focus();
            break;
        }
        else
            continue;
    }
}
function NAA_AtleastRowValidate(Row) {
    var PersonalEassy = 'ctl00_CPH_Achievement_PersonalEssay_TXTA';
    var ActivityLevel = 'ctl00_CPH_Achievement_ActivityLevel_DDL' + Row;
    var ActivityCategory = 'ctl00_CPH_Achievement_ActivityCategory_DDL' + Row;
    var ActivityName = 'ctl00_CPH_Achievement_ActivityName_TXT' + Row;
    var PositionHeld = 'ctl00_CPH_Achievement_PositionHeld_TXT' + Row;
    var ActivityFromDate = 'ctl00_CPH_Achievement_ActivityFromDate_TXT' + Row;
    var ActivityToDate = 'ctl00_CPH_Achievement_ActivityToDate_TXT' + Row;
    var ActivityDesc = 'ctl00_CPH_Achievement_ListOFAward_TXT' + Row;
    var errorMsg = "Please provide atleast one activity details";
    if (document.getElementById(ActivityLevel).value == '' &&
         document.getElementById(ActivityCategory).value == '' &&
         document.getElementById(ActivityName).value == '' &&
         document.getElementById(PositionHeld).value == '' &&
         document.getElementById(ActivityFromDate).value == '' &&
         document.getElementById(ActivityToDate).value == '' &&
         document.getElementById(ActivityDesc).value == '') {
        alert(errorMsg);
        document.getElementById(PersonalEassy).value = '';
        document.getElementById(ActivityLevel).selectedIndex = 0;
        document.getElementById(ActivityLevel).focus();
    }
    else {
        if (document.getElementById(ActivityLevel).value == '') {
            alert('Please indicate level of participation');
            document.getElementById(ActivityLevel).selectedIndex = 0;
            document.getElementById(ActivityLevel).focus();
        }
        else if (document.getElementById(ActivityCategory).value == '') {
            alert('Please indicate Category of participation');
            document.getElementById(ActivityCategory).selectedIndex = 0;
            document.getElementById(ActivityCategory).focus();
        }
        else if (document.getElementById(ActivityName).value == '') {
            alert('Please indicate name of activity/event/competition');
            document.getElementById(ActivityName).focus();
        }
        else if (document.getElementById(PositionHeld).value == '') {
            alert('Please indicate position held');
            document.getElementById(PositionHeld).focus();
        }
        else if (document.getElementById(ActivityFromDate).value == '') {
            alert('Please provide the start date in ‘From’ column in MMM-YYYY format');
            document.getElementById(ActivityFromDate).focus();
        }
        else if (document.getElementById(ActivityFromDate).value != '' && !isValidDate(document.getElementById(ActivityFromDate).value)) {
            document.getElementById(ActivityFromDate).value = '';
            alert('Please provide the start date in ‘From’ column in MMM-YYYY format');
            document.getElementById(ActivityFromDate).focus();
        }
        else if (document.getElementById(ActivityToDate).value == '') {
            alert('Please provide the end date in ‘To’ column in MMM-YYYY format');
            document.getElementById(ActivityToDate).focus();
        }
        else if (document.getElementById(ActivityToDate).value != '' && !isValidDate(document.getElementById(ActivityToDate).value)) {
            document.getElementById(ActivityToDate).value = '';
            alert('Please provide the end date in ‘To’ column in MMM-YYYY format');
            document.getElementById(ActivityToDate).focus();
        }
        else if (document.getElementById(ActivityDesc).value == '') {
            alert('Please list awards/certificates received or elaborate your involvements');
            document.getElementById(ActivityDesc).focus();
        }
    }
}
var arr = [];
arr['JAN'] = 0;
arr['FEB'] = 1;
arr['MAR'] = 2;
arr['APR'] = 3;
arr['MAY'] = 4;
arr['JUN'] = 5;
arr['JUL'] = 6;
arr['AUG'] = 7;
arr['SEP'] = 8;
arr['OCT'] = 9;
arr['NOV'] = 10;
arr['DEC'] = 11;

function isValidDate(strDate) {
    var arrDate = strDate.split('-');
    if (arrDate.length == 2 && strDate.length == 8) {
        var d = new Date(arrDate[1], arr[arrDate[0].toUpperCase()]);
        if (d.getFullYear() == arrDate[1] && d.getMonth() == arr[arrDate[0].toUpperCase()]) {
            return true;
        }
    }
    return false;
}


/*NAA - Validation End*/
